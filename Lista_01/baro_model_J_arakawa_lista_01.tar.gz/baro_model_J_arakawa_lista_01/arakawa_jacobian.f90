!===============================================================================
! Module: arakawa_extended
! Purpose: Jacobiano de Arakawa com 14 esquemas para modelo barotropico
!
! ESQUEMAS:
!   2a ordem (1-6):  JPP, JPXX, JXXP, JARA, JPP_XXP, JPP_PXX
!   4a ordem (7-10): JPP4, JPXX4, JXXP4, JARA4
!   Outros (11-14):  JSBP4, JSPECTRAL, JENO4, JMFD4
!
! CONDICOES DE CONTORNO SUPORTADAS:
!   BC_PERIODIC        : periodico em X e Y
!   BC_WALL            : parede em X e Y (reflexao par)
!   BC_CHANNEL         : periodico em X, parede em Y (canal)
!
! NOTA SOBRE GHOST CELLS:
!   Esquemas de 2a ordem precisam de 1 camada de ghost cells
!   Esquemas de 4a ordem, ENO4, SBP4, MFD4 precisam de 2 camadas
!   O caller deve dimensionar arrays como f(-1:NX+2, -1:NY+2)
!   e chamar boundary_fill_2layers() antes de arakawa_compute()
!
! ESPECTRAL (esquema 12, corrigido):
!   FFT de radix misto (comprimento qualquer), dealiasing 3/2 feito no
!   espectro (grade fina 96 x 48 ou 96 x 99 para NX=64, NY=32).
!   BC_CHANNEL: extensao impar em y (periodo 2*NY+2). BC_WALL: nao suportado.
!   Requer NX par (e NY par se BC_PERIODIC).
!
! COMPILACAO:
!   gfortran -O2 -ffree-line-length-none arakawa_jacobian.f90 baro.f90
!===============================================================================
module arakawa_extended
  implicit none
  private

  ! Public API
  public :: arakawa_compute, arakawa_scheme_name
  public :: boundary_fill_2layers, access_val
  public :: fft_init, fft_cleanup
  public :: compute_energy_enstrophy

  ! Scheme identifiers
  integer, parameter, public :: JPP       = 1
  integer, parameter, public :: JPXX      = 2
  integer, parameter, public :: JXXP      = 3
  integer, parameter, public :: JARA      = 4
  integer, parameter, public :: JPP_XXP   = 5
  integer, parameter, public :: JPP_PXX   = 6
  integer, parameter, public :: JPP4      = 7
  integer, parameter, public :: JPXX4     = 8
  integer, parameter, public :: JXXP4     = 9
  integer, parameter, public :: JARA4     = 10
  integer, parameter, public :: JSBP4     = 11
  integer, parameter, public :: JSPECTRAL = 12
  integer, parameter, public :: JENO4     = 13
  integer, parameter, public :: JMFD4     = 14
  integer, parameter, public :: N_SCHEMES = 14

  ! Boundary condition types
  integer, parameter, public :: BC_PERIODIC = 1
  integer, parameter, public :: BC_WALL     = 2
  integer, parameter, public :: BC_CHANNEL  = 3  ! periodic X, wall Y

  ! FFT internal state
  complex, allocatable :: fft_wk1(:), fft_wk2(:)
  integer, allocatable :: fft_bitrev(:)
  complex, allocatable :: fft_omega(:)
  integer :: fft_nx_save = 0, fft_ny_save = 0
  logical :: fft_ready = .false.

contains

  !=============================================================================
  ! Nome do esquema
  !=============================================================================
  function arakawa_scheme_name(ischeme) result(name)
    integer, intent(in) :: ischeme
    character(len=50)   :: name
    select case (ischeme)
    case (JPP);       name = 'J++ 2nd order (non-conservative)'
    case (JPXX);      name = 'J+x 2nd order (enstrophy-conserving)'
    case (JXXP);      name = 'Jx+ 2nd order (energy-conserving)'
    case (JARA);      name = 'Arakawa 2nd order (both conserved)'
    case (JPP_XXP);   name = '(J++ + Jx+)/2 2nd order'
    case (JPP_PXX);   name = '(J++ + J+x)/2 2nd order'
    case (JPP4);      name = 'J++ 4th order'
    case (JPXX4);     name = 'J+x 4th order (energy-conserving)'
    case (JXXP4);     name = 'Jx+ 4th order (enstrophy-conserving)'
    case (JARA4);     name = 'Arakawa 4th order'
    case (JSBP4);     name = 'SBP 4th order (Sorgento et al. 2015)'
    case (JSPECTRAL); name = 'Pseudospectral FFT + 3/2 dealiasing'
    case (JENO4);     name = 'ENO 4th order'
    case (JMFD4);     name = 'Mimetic Finite Difference 4th order'
    case default;     name = 'UNKNOWN'
    end select
  end function arakawa_scheme_name

  !=============================================================================
  ! Access value with boundary condition mapping
  ! Maps index (i,j) to valid position according to bc_type
  ! Works for i in [-1, NX+2] and j in [-1, NY+2]
  !=============================================================================
  function access_val(f, i, j, NX, NY, bc_type) result(val)
    real, intent(in)    :: f(-1:NX+2, -1:NY+2)
    integer, intent(in) :: i, j, NX, NY, bc_type
    real                :: val
    integer :: ii, jj

    ii = i; jj = j

    if (ii >= 1 .and. ii <= NX .and. jj >= 1 .and. jj <= NY) then
       val = f(ii, jj)
       return
    end if

    select case (bc_type)
    case (BC_PERIODIC)
       ! Wrap around in both directions
       ii = mod(ii - 1, NX)
       if (ii < 0) ii = ii + NX
       ii = ii + 1
       jj = mod(jj - 1, NY)
       if (jj < 0) jj = jj + NY
       jj = jj + 1
       val = f(ii, jj)

    case (BC_WALL)
       ! Even reflection in both directions
       if (ii < 1)  ii = 2 - ii
       if (ii > NX) ii = 2*NX - ii
       if (jj < 1)  jj = 2 - jj
       if (jj > NY) jj = 2*NY - jj
       ! Handle double reflections
       if (ii < 1)  ii = 2 - ii
       if (ii > NX) ii = 2*NX - ii
       if (jj < 1)  jj = 2 - jj
       if (jj > NY) jj = 2*NY - jj
       val = f(ii, jj)

    case (BC_CHANNEL)
       ! Periodic in X, wall in Y
       if (ii < 1) then
          ii = mod(ii - 1, NX)
          if (ii < 0) ii = ii + NX
          ii = ii + 1
       else if (ii > NX) then
          ii = mod(ii - 1, NX) + 1
       end if
       if (jj < 1)  jj = 2 - jj
       if (jj > NY) jj = 2*NY - jj
       if (jj < 1)  jj = 2 - jj
       if (jj > NY) jj = 2*NY - jj
       val = f(ii, jj)

    case default
       val = 0.0
    end select
  end function access_val

  !=============================================================================
  ! Fill 2 layers of ghost cells
  !=============================================================================
  subroutine boundary_fill_2layers(f, NX, NY, bc_type)
    integer, intent(in) :: NX, NY, bc_type
    real, intent(inout) :: f(-1:NX+2, -1:NY+2)
    integer :: i, j

    select case (bc_type)
    case (BC_PERIODIC)
       ! X boundaries (periodic)
       f(0, 1:NY)  = f(NX, 1:NY)
       f(-1, 1:NY) = f(NX-1, 1:NY)
       f(NX+1, 1:NY) = f(1, 1:NY)
       f(NX+2, 1:NY) = f(2, 1:NY)
       ! Y boundaries (periodic)
       f(1:NX, 0)  = f(1:NX, NY)
       f(1:NX, -1) = f(1:NX, NY-1)
       f(1:NX, NY+1) = f(1:NX, 1)
       f(1:NX, NY+2) = f(1:NX, 2)
       ! Corners
       f(0, 0) = f(NX, NY); f(-1, 0) = f(NX-1, NY)
       f(0, -1) = f(NX, NY-1); f(-1, -1) = f(NX-1, NY-1)
       f(NX+1, NY+1) = f(1, 1); f(NX+2, NY+1) = f(2, 1)
       f(NX+1, NY+2) = f(1, 2); f(NX+2, NY+2) = f(2, 2)
       f(0, NY+1) = f(NX, 1); f(-1, NY+1) = f(NX-1, 1)
       f(0, NY+2) = f(NX, 2); f(-1, NY+2) = f(NX-1, 2)
       f(NX+1, 0) = f(1, NY); f(NX+2, 0) = f(2, NY)
       f(NX+1, -1) = f(1, NY-1); f(NX+2, -1) = f(2, NY-1)

    case (BC_WALL)
       ! X boundaries (wall = Dirichlet zero)
       do j = -1, NY+2
          f(0, j)    = 0.
          f(-1, j)   = 0.
          f(NX+1, j) = 0.
          f(NX+2, j) = 0.
       end do
       ! Y boundaries (wall = Dirichlet zero)
       do i = -1, NX+2
          f(i, 0)    = 0.
          f(i, -1)   = 0.
          f(i, NY+1) = 0.
          f(i, NY+2) = 0.
       end do

    case (BC_CHANNEL)
       ! X boundaries (periodic)
       f(0, 1:NY)  = f(NX, 1:NY)
       f(-1, 1:NY) = f(NX-1, 1:NY)
       f(NX+1, 1:NY) = f(1, 1:NY)
       f(NX+2, 1:NY) = f(2, 1:NY)
       ! Y boundaries (wall = Dirichlet zero, igual ao baro.f90 original)
       do i = -1, NX+2
          f(i, 0)    = 0.
          f(i, -1)   = 0.
          f(i, NY+1) = 0.
          f(i, NY+2) = 0.
       end do
    end select
  end subroutine boundary_fill_2layers

  !=============================================================================
  ! 2nd ORDER ARAKAWA SCHEMES
  !=============================================================================
  subroutine compute_j2(psi, zeta, zj1, zj2, zj3, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj1(NX,NY), zj2(NX,NY), zj3(NX,NY)
    integer :: i, j
    real    :: rdx, rdy

    rdx = 1.0 / (2.0 * dx)
    rdy = 1.0 / (2.0 * dy)

    do j = 1, NY
       do i = 1, NX
          zj1(i,j) = rdx*(access_val(psi,i+1,j,NX,NY,bc_type)-access_val(psi,i-1,j,NX,NY,bc_type)) &
                   * rdy*(access_val(zeta,i,j+1,NX,NY,bc_type)-access_val(zeta,i,j-1,NX,NY,bc_type)) &
                   - rdy*(access_val(psi,i,j+1,NX,NY,bc_type)-access_val(psi,i,j-1,NX,NY,bc_type)) &
                   * rdx*(access_val(zeta,i+1,j,NX,NY,bc_type)-access_val(zeta,i-1,j,NX,NY,bc_type))

          zj2(i,j) = rdy*( &
               access_val(zeta,i,j+1,NX,NY,bc_type)*rdx*(access_val(psi,i+1,j+1,NX,NY,bc_type)-access_val(psi,i-1,j+1,NX,NY,bc_type)) &
             - access_val(zeta,i,j-1,NX,NY,bc_type)*rdx*(access_val(psi,i+1,j-1,NX,NY,bc_type)-access_val(psi,i-1,j-1,NX,NY,bc_type)) ) &
                   - rdx*( &
               access_val(zeta,i+1,j,NX,NY,bc_type)*rdy*(access_val(psi,i+1,j+1,NX,NY,bc_type)-access_val(psi,i+1,j-1,NX,NY,bc_type)) &
             - access_val(zeta,i-1,j,NX,NY,bc_type)*rdy*(access_val(psi,i-1,j+1,NX,NY,bc_type)-access_val(psi,i-1,j-1,NX,NY,bc_type)) )

          zj3(i,j) = rdx*( &
               access_val(psi,i+1,j,NX,NY,bc_type)*rdy*(access_val(zeta,i+1,j+1,NX,NY,bc_type)-access_val(zeta,i+1,j-1,NX,NY,bc_type)) &
             - access_val(psi,i-1,j,NX,NY,bc_type)*rdy*(access_val(zeta,i-1,j+1,NX,NY,bc_type)-access_val(zeta,i-1,j-1,NX,NY,bc_type)) ) &
                   - rdy*( &
               access_val(psi,i,j+1,NX,NY,bc_type)*rdx*(access_val(zeta,i+1,j+1,NX,NY,bc_type)-access_val(zeta,i-1,j+1,NX,NY,bc_type)) &
             - access_val(psi,i,j-1,NX,NY,bc_type)*rdx*(access_val(zeta,i+1,j-1,NX,NY,bc_type)-access_val(zeta,i-1,j-1,NX,NY,bc_type)) )
       end do
    end do
  end subroutine compute_j2

  !=============================================================================
  ! 4th ORDER ARAKAWA SCHEMES
  ! Stencil: i-2, i-1, i, i+1, i+2 (5-point)
  ! Requires 2 layers of ghost cells
  !=============================================================================
  subroutine compute_j4(psi, zeta, zj1, zj2, zj3, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj1(NX,NY), zj2(NX,NY), zj3(NX,NY)
    integer :: i, j
    real    :: rdx12, rdy12

    rdx12 = 1.0 / (12.0 * dx)
    rdy12 = 1.0 / (12.0 * dy)

    do j = 1, NY
       do i = 1, NX
          ! J++ 4th order: 4th order central differences
          zj1(i,j) = rdx12*( -access_val(psi,i+2,j,NX,NY,bc_type) + 8*access_val(psi,i+1,j,NX,NY,bc_type) &
                             -8*access_val(psi,i-1,j,NX,NY,bc_type) +   access_val(psi,i-2,j,NX,NY,bc_type) ) &
                   * rdy12*( -access_val(zeta,i,j+2,NX,NY,bc_type) + 8*access_val(zeta,i,j+1,NX,NY,bc_type) &
                             -8*access_val(zeta,i,j-1,NX,NY,bc_type) +   access_val(zeta,i,j-2,NX,NY,bc_type) ) &
                   - rdy12*( -access_val(psi,i,j+2,NX,NY,bc_type) + 8*access_val(psi,i,j+1,NX,NY,bc_type) &
                             -8*access_val(psi,i,j-1,NX,NY,bc_type) +   access_val(psi,i,j-2,NX,NY,bc_type) ) &
                   * rdx12*( -access_val(zeta,i+2,j,NX,NY,bc_type) + 8*access_val(zeta,i+1,j,NX,NY,bc_type) &
                             -8*access_val(zeta,i-1,j,NX,NY,bc_type) +   access_val(zeta,i-2,j,NX,NY,bc_type) )

          ! J+x 4th order (flux-zeta)
          zj2(i,j) = rdy12*( &
               access_val(zeta,i,j+2,NX,NY,bc_type)*rdx12*(-access_val(psi,i+2,j+2,NX,NY,bc_type)+8*access_val(psi,i+1,j+2,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-1,j+2,NX,NY,bc_type)+access_val(psi,i-2,j+2,NX,NY,bc_type)) &
            -8*access_val(zeta,i,j+1,NX,NY,bc_type)*rdx12*(-access_val(psi,i+2,j+1,NX,NY,bc_type)+8*access_val(psi,i+1,j+1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-1,j+1,NX,NY,bc_type)+access_val(psi,i-2,j+1,NX,NY,bc_type)) &
            +8*access_val(zeta,i,j-1,NX,NY,bc_type)*rdx12*(-access_val(psi,i+2,j-1,NX,NY,bc_type)+8*access_val(psi,i+1,j-1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-1,j-1,NX,NY,bc_type)+access_val(psi,i-2,j-1,NX,NY,bc_type)) &
              -access_val(zeta,i,j-2,NX,NY,bc_type)*rdx12*(-access_val(psi,i+2,j-2,NX,NY,bc_type)+8*access_val(psi,i+1,j-2,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-1,j-2,NX,NY,bc_type)+access_val(psi,i-2,j-2,NX,NY,bc_type)) ) &
                   - rdx12*( &
               access_val(zeta,i+2,j,NX,NY,bc_type)*rdy12*(-access_val(psi,i+2,j+2,NX,NY,bc_type)+8*access_val(psi,i+2,j+1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i+2,j-1,NX,NY,bc_type)+access_val(psi,i+2,j-2,NX,NY,bc_type)) &
            -8*access_val(zeta,i+1,j,NX,NY,bc_type)*rdy12*(-access_val(psi,i+1,j+2,NX,NY,bc_type)+8*access_val(psi,i+1,j+1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i+1,j-1,NX,NY,bc_type)+access_val(psi,i+1,j-2,NX,NY,bc_type)) &
            +8*access_val(zeta,i-1,j,NX,NY,bc_type)*rdy12*(-access_val(psi,i-1,j+2,NX,NY,bc_type)+8*access_val(psi,i-1,j+1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-1,j-1,NX,NY,bc_type)+access_val(psi,i-1,j-2,NX,NY,bc_type)) &
              -access_val(zeta,i-2,j,NX,NY,bc_type)*rdy12*(-access_val(psi,i-2,j+2,NX,NY,bc_type)+8*access_val(psi,i-2,j+1,NX,NY,bc_type) &
                                                           -8*access_val(psi,i-2,j-1,NX,NY,bc_type)+access_val(psi,i-2,j-2,NX,NY,bc_type)) )

          ! Jx+ 4th order (flux-psi)
          zj3(i,j) = rdx12*( &
               access_val(psi,i+2,j,NX,NY,bc_type)*rdy12*(-access_val(zeta,i+2,j+2,NX,NY,bc_type)+8*access_val(zeta,i+2,j+1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i+2,j-1,NX,NY,bc_type)+access_val(zeta,i+2,j-2,NX,NY,bc_type)) &
            -8*access_val(psi,i+1,j,NX,NY,bc_type)*rdy12*(-access_val(zeta,i+1,j+2,NX,NY,bc_type)+8*access_val(zeta,i+1,j+1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i+1,j-1,NX,NY,bc_type)+access_val(zeta,i+1,j-2,NX,NY,bc_type)) &
            +8*access_val(psi,i-1,j,NX,NY,bc_type)*rdy12*(-access_val(zeta,i-1,j+2,NX,NY,bc_type)+8*access_val(zeta,i-1,j+1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-1,j-1,NX,NY,bc_type)+access_val(zeta,i-1,j-2,NX,NY,bc_type)) &
              -access_val(psi,i-2,j,NX,NY,bc_type)*rdy12*(-access_val(zeta,i-2,j+2,NX,NY,bc_type)+8*access_val(zeta,i-2,j+1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-2,j-1,NX,NY,bc_type)+access_val(zeta,i-2,j-2,NX,NY,bc_type)) ) &
                   - rdy12*( &
               access_val(psi,i,j+2,NX,NY,bc_type)*rdx12*(-access_val(zeta,i+2,j+2,NX,NY,bc_type)+8*access_val(zeta,i+1,j+2,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-1,j+2,NX,NY,bc_type)+access_val(zeta,i-2,j+2,NX,NY,bc_type)) &
            -8*access_val(psi,i,j+1,NX,NY,bc_type)*rdx12*(-access_val(zeta,i+2,j+1,NX,NY,bc_type)+8*access_val(zeta,i+1,j+1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-1,j+1,NX,NY,bc_type)+access_val(zeta,i-2,j+1,NX,NY,bc_type)) &
            +8*access_val(psi,i,j-1,NX,NY,bc_type)*rdx12*(-access_val(zeta,i+2,j-1,NX,NY,bc_type)+8*access_val(zeta,i+1,j-1,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-1,j-1,NX,NY,bc_type)+access_val(zeta,i-2,j-1,NX,NY,bc_type)) &
              -access_val(psi,i,j-2,NX,NY,bc_type)*rdx12*(-access_val(zeta,i+2,j-2,NX,NY,bc_type)+8*access_val(zeta,i+1,j-2,NX,NY,bc_type) &
                                                          -8*access_val(zeta,i-1,j-2,NX,NY,bc_type)+access_val(zeta,i-2,j-2,NX,NY,bc_type)) )
          ! CORRECAO: a derivada externa de 4a ordem acima usa (+A(+2) -8A(+1) +8A(-1) -A(-2)),
          ! que e o NEGATIVO da diferenca centrada. Corrige o sinal de zj2 e zj3.
          zj2(i,j) = -zj2(i,j)
          zj3(i,j) = -zj3(i,j)
       end do
    end do
  end subroutine compute_j4

  !=============================================================================
  ! SBP 4th ORDER (Sorgento et al. 2015 style)
  ! Summation-By-Parts operator with boundary closures
  ! Uses 4th order interior + 2nd order boundary closures
  !=============================================================================
  subroutine compute_jsbp4(psi, zeta, zj, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj(NX,NY)
    integer :: i, j
    real    :: rdx12, rdy12
    real    :: dpsidx, dpsidy, dzetadx, dzetady

    rdx12 = 1.0 / (12.0 * dx)
    rdy12 = 1.0 / (12.0 * dy)

    do j = 1, NY
       do i = 1, NX
          if (i == 1 .or. i == NX .or. j == 1 .or. j == NY) then
             ! Boundary: use 2nd order Arakawa (JARA)
             call compute_j2_at_point(psi, zeta, i, j, zj(i,j), NX, NY, dx, dy, bc_type)
          else
             ! Interior: 4th order compact SBP-like
             dpsidx = rdx12*(-access_val(psi,i+2,j,NX,NY,bc_type) + 8*access_val(psi,i+1,j,NX,NY,bc_type) &
                            -8*access_val(psi,i-1,j,NX,NY,bc_type) +   access_val(psi,i-2,j,NX,NY,bc_type))
             dpsidy = rdy12*(-access_val(psi,i,j+2,NX,NY,bc_type) + 8*access_val(psi,i,j+1,NX,NY,bc_type) &
                            -8*access_val(psi,i,j-1,NX,NY,bc_type) +   access_val(psi,i,j-2,NX,NY,bc_type))
             dzetadx = rdx12*(-access_val(zeta,i+2,j,NX,NY,bc_type) + 8*access_val(zeta,i+1,j,NX,NY,bc_type) &
                             -8*access_val(zeta,i-1,j,NX,NY,bc_type) +   access_val(zeta,i-2,j,NX,NY,bc_type))
             dzetady = rdy12*(-access_val(zeta,i,j+2,NX,NY,bc_type) + 8*access_val(zeta,i,j+1,NX,NY,bc_type) &
                             -8*access_val(zeta,i,j-1,NX,NY,bc_type) +   access_val(zeta,i,j-2,NX,NY,bc_type))
             zj(i,j) = dpsidx * dzetady - dpsidy * dzetadx
          end if
       end do
    end do
  end subroutine compute_jsbp4

  ! Helper for SBP4 boundary
  subroutine compute_j2_at_point(psi, zeta, i, j, val, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: i, j, NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: val
    real    :: rdx, rdy, t1, t2, t3

    rdx = 1.0 / (2.0 * dx)
    rdy = 1.0 / (2.0 * dy)

    t1 = rdx*(access_val(psi,i+1,j,NX,NY,bc_type)-access_val(psi,i-1,j,NX,NY,bc_type)) &
       * rdy*(access_val(zeta,i,j+1,NX,NY,bc_type)-access_val(zeta,i,j-1,NX,NY,bc_type)) &
       - rdy*(access_val(psi,i,j+1,NX,NY,bc_type)-access_val(psi,i,j-1,NX,NY,bc_type)) &
       * rdx*(access_val(zeta,i+1,j,NX,NY,bc_type)-access_val(zeta,i-1,j,NX,NY,bc_type))

    t2 = rdy*( &
         access_val(zeta,i,j+1,NX,NY,bc_type)*rdx*(access_val(psi,i+1,j+1,NX,NY,bc_type)-access_val(psi,i-1,j+1,NX,NY,bc_type)) &
       - access_val(zeta,i,j-1,NX,NY,bc_type)*rdx*(access_val(psi,i+1,j-1,NX,NY,bc_type)-access_val(psi,i-1,j-1,NX,NY,bc_type)) ) &
         - rdx*( &
         access_val(zeta,i+1,j,NX,NY,bc_type)*rdy*(access_val(psi,i+1,j+1,NX,NY,bc_type)-access_val(psi,i+1,j-1,NX,NY,bc_type)) &
       - access_val(zeta,i-1,j,NX,NY,bc_type)*rdy*(access_val(psi,i-1,j+1,NX,NY,bc_type)-access_val(psi,i-1,j-1,NX,NY,bc_type)) )

    t3 = rdx*( &
         access_val(psi,i+1,j,NX,NY,bc_type)*rdy*(access_val(zeta,i+1,j+1,NX,NY,bc_type)-access_val(zeta,i+1,j-1,NX,NY,bc_type)) &
       - access_val(psi,i-1,j,NX,NY,bc_type)*rdy*(access_val(zeta,i-1,j+1,NX,NY,bc_type)-access_val(zeta,i-1,j-1,NX,NY,bc_type)) ) &
         - rdy*( &
         access_val(psi,i,j+1,NX,NY,bc_type)*rdx*(access_val(zeta,i+1,j+1,NX,NY,bc_type)-access_val(zeta,i-1,j+1,NX,NY,bc_type)) &
       - access_val(psi,i,j-1,NX,NY,bc_type)*rdx*(access_val(zeta,i+1,j-1,NX,NY,bc_type)-access_val(zeta,i-1,j-1,NX,NY,bc_type)) )

    val = (t1 + t2 + t3) / 3.0
  end subroutine compute_j2_at_point

  !=============================================================================
  ! PSEUDOESPECTRAL (esquema 12) - CORRIGIDO
  !  - FFT de comprimento qualquer (radix misto): padding 3/2 -> 96 x 48/99
  !  - padding feito NO ESPECTRO (mesmo dominio, grade mais fina), nao em
  !    zeros no espaco fisico
  !  - dkx = 2*pi/(NX*dx), dky = 2*pi/(NYE*dy)  (comprimento do dominio real)
  !  - modo de Nyquist anulado nas derivadas
  !  - sem fator "scale" espurio: forward sem 1/N, inverse com 1/N
  !  - BC_CHANNEL: extensao IMPAR em y em torno das paredes j=0 e j=NY+1
  !    (periodo NYE = 2*NY+2), consistente com psi = 0 nas paredes
  !  - BC_PERIODIC: periodico em x e y.  BC_WALL: nao suportado.
  ! Requer NX par e (NY par se periodico).
  !=============================================================================
  subroutine compute_jspectral(psi, zeta, zj, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj(NX,NY)
    integer :: i, j, ip, jp, kx, ky, nye, nxp, nyp
    real, allocatable    :: pe(:,:), ze(:,:), jo(:,:)
    real, allocatable    :: dpx(:,:), dpy(:,:), dzx(:,:), dzy(:,:), jphys(:,:)
    complex, allocatable :: ph(:,:), zh(:,:), jh(:,:), jh0(:,:)
    complex, allocatable :: dpx_h(:,:), dpy_h(:,:), dzx_h(:,:), dzy_h(:,:)
    real    :: dkx, dky, pi2, sc, wx, wy

    if (bc_type == BC_WALL) then
       print *, 'ERRO compute_jspectral: BC_WALL nao suportado (use BC_CHANNEL ou BC_PERIODIC)'
       stop
    end if

    pi2 = 2.0 * 3.141592653589793
    if (bc_type == BC_CHANNEL) then
       nye = 2*NY + 2
    else
       nye = NY
    end if
    nxp = 3 * NX / 2
    nyp = 3 * nye / 2

    allocate(pe(NX,nye), ze(NX,nye), jo(NX,nye))
    allocate(ph(NX,nye), zh(NX,nye), jh0(NX,nye))
    allocate(dpx_h(nxp,nyp), dpy_h(nxp,nyp), dzx_h(nxp,nyp), dzy_h(nxp,nyp), jh(nxp,nyp))
    allocate(dpx(nxp,nyp), dpy(nxp,nyp), dzx(nxp,nyp), dzy(nxp,nyp), jphys(nxp,nyp))

    ! Campo (estendido) no dominio periodico
    do j = 1, NY
       pe(:,j) = psi(1:NX,j)
       ze(:,j) = zeta(1:NX,j)
    end do
    if (bc_type == BC_CHANNEL) then
       pe(:,NY+1) = 0.0;  ze(:,NY+1) = 0.0       ! parede em y = (NY+1)*dy
       pe(:,nye)  = 0.0;  ze(:,nye)  = 0.0       ! parede em y = 0
       do j = 1, NY
          pe(:,NY+1+j) = -psi (1:NX,NY+1-j)      ! reflexao impar
          ze(:,NY+1+j) = -zeta(1:NX,NY+1-j)
       end do
    end if

    call fft2d_forward(pe, ph, NX, nye)
    call fft2d_forward(ze, zh, NX, nye)

    dkx = pi2 / (real(NX)  * dx)
    dky = pi2 / (real(nye) * dy)
    sc  = real(nxp) * real(nyp) / (real(NX) * real(nye))

    ! Derivadas espectrais, ja copiadas para o espectro com padding 3/2
    dpx_h = (0.0,0.0); dpy_h = (0.0,0.0); dzx_h = (0.0,0.0); dzy_h = (0.0,0.0)
    do j = 1, nye
       ky = j - 1
       if (ky > nye/2) ky = ky - nye
       if (2*abs(ky) >= nye) cycle                 ! descarta Nyquist
       jp = ky + 1
       if (ky < 0) jp = nyp + ky + 1
       wy = dky * real(ky)
       do i = 1, NX
          kx = i - 1
          if (kx > NX/2) kx = kx - NX
          if (2*abs(kx) >= NX) cycle
          ip = kx + 1
          if (kx < 0) ip = nxp + kx + 1
          wx = dkx * real(kx)
          dpx_h(ip,jp) = cmplx(0.0, wx) * ph(i,j) * sc
          dpy_h(ip,jp) = cmplx(0.0, wy) * ph(i,j) * sc
          dzx_h(ip,jp) = cmplx(0.0, wx) * zh(i,j) * sc
          dzy_h(ip,jp) = cmplx(0.0, wy) * zh(i,j) * sc
       end do
    end do

    call fft2d_inverse(dpx_h, dpx, nxp, nyp)
    call fft2d_inverse(dpy_h, dpy, nxp, nyp)
    call fft2d_inverse(dzx_h, dzx, nxp, nyp)
    call fft2d_inverse(dzy_h, dzy, nxp, nyp)

    jphys = dpx * dzy - dpy * dzx                   ! J na grade fina

    call fft2d_forward(jphys, jh, nxp, nyp)

    ! Trunca de volta para a resolucao original (dealiasing 3/2 exato)
    jh0 = (0.0,0.0)
    do j = 1, nye
       ky = j - 1
       if (ky > nye/2) ky = ky - nye
       if (2*abs(ky) >= nye) cycle
       jp = ky + 1
       if (ky < 0) jp = nyp + ky + 1
       do i = 1, NX
          kx = i - 1
          if (kx > NX/2) kx = kx - NX
          if (2*abs(kx) >= NX) cycle
          ip = kx + 1
          if (kx < 0) ip = nxp + kx + 1
          jh0(i,j) = jh(ip,jp) / sc
       end do
    end do

    call fft2d_inverse(jh0, jo, NX, nye)

    do j = 1, NY
       zj(:,j) = jo(:,j)
    end do

    deallocate(pe, ze, jo, ph, zh, jh0, dpx_h, dpy_h, dzx_h, dzy_h, jh)
    deallocate(dpx, dpy, dzx, dzy, jphys)
  end subroutine compute_jspectral

  !=============================================================================
  ! 2D FFT (radix misto) - forward, sem normalizacao
  !=============================================================================
  subroutine fft2d_forward(fin, fh, nx, ny)
    integer, intent(in)  :: nx, ny
    real, intent(in)     :: fin(nx, ny)
    complex, intent(out) :: fh(nx, ny)
    complex, allocatable :: row(:), col(:)
    integer :: i, j
    allocate(row(nx), col(ny))
    do j = 1, ny
       do i = 1, nx
          row(i) = cmplx(fin(i,j), 0.0)
       end do
       call fft1d(row, nx, -1)
       fh(:,j) = row
    end do
    do i = 1, nx
       col = fh(i,:)
       call fft1d(col, ny, -1)
       fh(i,:) = col
    end do
    deallocate(row, col)
  end subroutine fft2d_forward

  ! 2D FFT - inverse (com 1/(nx*ny))
  subroutine fft2d_inverse(fh, fout, nx, ny)
    integer, intent(in)  :: nx, ny
    complex, intent(in)  :: fh(nx, ny)
    real, intent(out)    :: fout(nx, ny)
    complex, allocatable :: row(:), col(:), tmp(:,:)
    integer :: i, j
    allocate(row(nx), col(ny), tmp(nx, ny))
    tmp = fh
    do j = 1, ny
       row = tmp(:,j)
       call fft1d(row, nx, 1)
       tmp(:,j) = row
    end do
    do i = 1, nx
       col = tmp(i,:)
       call fft1d(col, ny, 1)
       tmp(i,:) = col
    end do
    do j = 1, ny
       do i = 1, nx
          fout(i,j) = real(tmp(i,j)) / real(nx * ny)
       end do
    end do
    deallocate(row, col, tmp)
  end subroutine fft2d_inverse

  ! FFT 1D de comprimento qualquer (radix misto, recursiva).
  ! isign = -1: direta;  isign = +1: inversa (sem 1/N).
  ! O codigo original usava radix-2 com passo de grupo errado (istep = 2*m)
  ! e nao funcionava para 96 ou 48 pontos.
  subroutine fft1d(a, n, isign)
    integer, intent(in)    :: n, isign
    complex, intent(inout) :: a(n)
    complex, allocatable   :: tw(:)
    real(8) :: ang, pi2d
    integer :: k
    if (n <= 1) return
    pi2d = 8.0d0 * atan(1.0d0)
    allocate(tw(0:n-1))
    do k = 0, n-1
       ang = real(isign,8) * pi2d * real(k,8) / real(n,8)
       tw(k) = cmplx(real(cos(ang)), real(sin(ang)))
    end do
    call fft_rec(a, n, tw, n)
    deallocate(tw)
  end subroutine fft1d

  recursive subroutine fft_rec(a, n, tw, ntop)
    integer, intent(in)    :: n, ntop
    complex, intent(inout) :: a(n)
    complex, intent(in)    :: tw(0:ntop-1)
    complex, allocatable   :: sub(:,:), b(:)
    complex :: s
    integer :: p, m, r, k, q, st
    if (n <= 1) return
    st = ntop / n                        ! W_n^e = tw(mod(e,n)*st)
    p = 2
    do while (mod(n,p) /= 0)
       p = p + 1
    end do
    allocate(b(n))
    if (p == n) then                     ! n primo: DFT direta
       do k = 0, n-1
          s = (0.0, 0.0)
          do r = 0, n-1
             s = s + a(r+1) * tw(mod(k*r, n) * st)
          end do
          b(k+1) = s
       end do
       a = b
       deallocate(b)
       return
    end if
    m = n / p
    allocate(sub(m,p))
    do r = 0, p-1
       do k = 0, m-1
          sub(k+1,r+1) = a(k*p + r + 1)
       end do
       call fft_rec(sub(:,r+1), m, tw, ntop)
    end do
    do q = 0, p-1
       do k = 0, m-1
          s = (0.0, 0.0)
          do r = 0, p-1
             s = s + tw(mod((k + q*m)*r, n) * st) * sub(k+1,r+1)
          end do
          b(k + q*m + 1) = s
       end do
    end do
    a = b
    deallocate(sub, b)
  end subroutine fft_rec


  !=============================================================================
  ! ENO 4th ORDER (esquema 13) - CORRIGIDO
  ! Derivada primeira em cada no a partir de dois candidatos de 3a ordem
  ! (stencils {i-2..i+1} e {i-1..i+2}). Em regiao suave, a media simples dos
  ! dois e a diferenca centrada de 4a ordem; perto de descontinuidades o peso
  ! migra para o stencil mais suave.
  ! O codigo original usava (-f(i-2)+3f(i-1)-3f(i)+f(i+1))/(3h), que e uma
  ! DIFERENCA TERCEIRA (~ h^2 f'''), nao uma derivada: o Jacobiano saia ~ 0.
  !=============================================================================
  subroutine compute_jeno4(psi, zeta, zj, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj(NX,NY)
    integer :: i, j
    real    :: dpsidx, dpsidy, dzetadx, dzetady

    do j = 1, NY
       do i = 1, NX
          dpsidx  = eno4_deriv_x(psi,  i, j, NX, NY, dx, bc_type)
          dpsidy  = eno4_deriv_y(psi,  i, j, NX, NY, dy, bc_type)
          dzetadx = eno4_deriv_x(zeta, i, j, NX, NY, dx, bc_type)
          dzetady = eno4_deriv_y(zeta, i, j, NX, NY, dy, bc_type)
          zj(i,j) = dpsidx * dzetady - dpsidy * dzetadx
       end do
    end do
  end subroutine compute_jeno4

  ! Nucleo ENO/WENO: derivada em f0 a partir de 5 pontos
  pure function eno4_stencil(fm2, fm1, f0, fp1, fp2, h) result(df)
    real, intent(in) :: fm2, fm1, f0, fp1, fp2, h
    real :: df
    real :: d1, d2, b1, b2, bm, a1, a2, r1, r2, tau
    real, parameter :: eps = 1.0e-6

    d1 = ( fm2 - 6.0*fm1 + 3.0*f0 + 2.0*fp1) / (6.0*h)   ! {i-2..i+1}
    d2 = (-2.0*fm1 - 3.0*f0 + 6.0*fp1 - fp2) / (6.0*h)   ! {i-1..i+2}

    ! indicadores de suavidade (segundas diferencas) de cada stencil
    b1 = (fm2 - 2.0*fm1 + f0 )**2 + (fm1 - 2.0*f0 + fp1)**2
    b2 = (fm1 - 2.0*f0  + fp1)**2 + (f0  - 2.0*fp1 + fp2)**2

    bm = max(b1, b2)
    if (bm <= tiny(1.0)) then
       df = 0.5 * (d1 + d2)
    else
       r1 = b1 / bm                      ! normalizado: invariante a escala
       r2 = b2 / bm
       tau = abs(r1 - r2)                ! pesos tipo WENO-Z (reduz o erro perto de f''=0)
       a1 = 0.5 * (1.0 + (tau / (eps + r1))**2)
       a2 = 0.5 * (1.0 + (tau / (eps + r2))**2)
       df = (a1*d1 + a2*d2) / (a1 + a2)
    end if
  end function eno4_stencil

  function eno4_deriv_x(f, i, j, NX, NY, h, bc_type) result(df)
    real, intent(in)    :: f(-1:NX+2, -1:NY+2)
    integer, intent(in) :: i, j, NX, NY, bc_type
    real, intent(in)    :: h
    real                :: df
    df = eno4_stencil(access_val(f,i-2,j,NX,NY,bc_type), access_val(f,i-1,j,NX,NY,bc_type), &
                      access_val(f,i  ,j,NX,NY,bc_type), access_val(f,i+1,j,NX,NY,bc_type), &
                      access_val(f,i+2,j,NX,NY,bc_type), h)
  end function eno4_deriv_x

  function eno4_deriv_y(f, i, j, NX, NY, h, bc_type) result(df)
    real, intent(in)    :: f(-1:NX+2, -1:NY+2)
    integer, intent(in) :: i, j, NX, NY, bc_type
    real, intent(in)    :: h
    real                :: df
    df = eno4_stencil(access_val(f,i,j-2,NX,NY,bc_type), access_val(f,i,j-1,NX,NY,bc_type), &
                      access_val(f,i,j  ,NX,NY,bc_type), access_val(f,i,j+1,NX,NY,bc_type), &
                      access_val(f,i,j+2,NX,NY,bc_type), h)
  end function eno4_deriv_y

  !=============================================================================
  ! MIMETIC FINITE DIFFERENCE 4th ORDER (MFD4)
  ! Mimetic operators satisfy discrete analogs of vector calculus identities
  ! Uses staggered grid approach for divergence/gradient consistency
  !=============================================================================
  subroutine compute_jmfd4(psi, zeta, zj, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj(NX,NY)
    integer :: i, j
    real    :: dpsidx, dpsidy, dzetadx, dzetady
    real    :: gradpsi_x(-1:NX+2, -1:NY+2), gradpsi_y(-1:NX+2, -1:NY+2)
    real    :: gradzeta_x(-1:NX+2, -1:NY+2), gradzeta_y(-1:NX+2, -1:NY+2)

    ! Compute mimetic gradients (4th order interior, 2nd order boundary)
    do j = 1, NY
       do i = 1, NX
          if (i == 1 .or. i == NX) then
             gradpsi_x(i,j)  = (access_val(psi,i+1,j,NX,NY,bc_type) - access_val(psi,i-1,j,NX,NY,bc_type)) / (2*dx)
             gradzeta_x(i,j) = (access_val(zeta,i+1,j,NX,NY,bc_type) - access_val(zeta,i-1,j,NX,NY,bc_type)) / (2*dx)
          else
             gradpsi_x(i,j)  = (-access_val(psi,i+2,j,NX,NY,bc_type) + 8*access_val(psi,i+1,j,NX,NY,bc_type) &
                                -8*access_val(psi,i-1,j,NX,NY,bc_type) + access_val(psi,i-2,j,NX,NY,bc_type)) / (12*dx)
             gradzeta_x(i,j) = (-access_val(zeta,i+2,j,NX,NY,bc_type) + 8*access_val(zeta,i+1,j,NX,NY,bc_type) &
                                -8*access_val(zeta,i-1,j,NX,NY,bc_type) + access_val(zeta,i-2,j,NX,NY,bc_type)) / (12*dx)
          end if

          if (j == 1 .or. j == NY) then
             gradpsi_y(i,j)  = (access_val(psi,i,j+1,NX,NY,bc_type) - access_val(psi,i,j-1,NX,NY,bc_type)) / (2*dy)
             gradzeta_y(i,j) = (access_val(zeta,i,j+1,NX,NY,bc_type) - access_val(zeta,i,j-1,NX,NY,bc_type)) / (2*dy)
          else
             gradpsi_y(i,j)  = (-access_val(psi,i,j+2,NX,NY,bc_type) + 8*access_val(psi,i,j+1,NX,NY,bc_type) &
                                -8*access_val(psi,i,j-1,NX,NY,bc_type) + access_val(psi,i,j-2,NX,NY,bc_type)) / (12*dy)
             gradzeta_y(i,j) = (-access_val(zeta,i,j+2,NX,NY,bc_type) + 8*access_val(zeta,i,j+1,NX,NY,bc_type) &
                                -8*access_val(zeta,i,j-1,NX,NY,bc_type) + access_val(zeta,i,j-2,NX,NY,bc_type)) / (12*dy)
          end if
       end do
    end do

    ! Jacobian = d(psi)/dx * d(zeta)/dy - d(psi)/dy * d(zeta)/dx
    do j = 1, NY
       do i = 1, NX
          zj(i,j) = gradpsi_x(i,j) * gradzeta_y(i,j) - gradpsi_y(i,j) * gradzeta_x(i,j)
       end do
    end do
  end subroutine compute_jmfd4

  !=============================================================================
  ! MAIN DRIVER: arakawa_compute
  !=============================================================================
  subroutine arakawa_compute(psi, zeta, zj, ischeme, NX, NY, dx, dy, bc_type)
    integer, intent(in)  :: ischeme, NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: zj(NX,NY)
    real, allocatable    :: zj1(:,:), zj2(:,:), zj3(:,:)

    zj = 0.0

    select case (ischeme)
    case (JPP, JPXX, JXXP, JARA, JPP_XXP, JPP_PXX)
       allocate(zj1(NX,NY), zj2(NX,NY), zj3(NX,NY))
       call compute_j2(psi, zeta, zj1, zj2, zj3, NX, NY, dx, dy, bc_type)
       select case (ischeme)
       case (JPP);     zj = zj1
       case (JPXX);    zj = zj2
       case (JXXP);    zj = zj3
       case (JARA);    zj = (zj1 + zj2 + zj3) / 3.0
       case (JPP_XXP); zj = 0.5 * (zj1 + zj3)
       case (JPP_PXX); zj = 0.5 * (zj1 + zj2)
       end select
       deallocate(zj1, zj2, zj3)

    case (JPP4, JPXX4, JXXP4, JARA4)
       allocate(zj1(NX,NY), zj2(NX,NY), zj3(NX,NY))
       call compute_j4(psi, zeta, zj1, zj2, zj3, NX, NY, dx, dy, bc_type)
       select case (ischeme)
       case (JPP4);    zj = zj1
       case (JPXX4);   zj = zj2
       case (JXXP4);   zj = zj3
       case (JARA4);   zj = (zj1 + zj2 + zj3) / 3.0
       end select
       deallocate(zj1, zj2, zj3)

    case (JSBP4)
       call compute_jsbp4(psi, zeta, zj, NX, NY, dx, dy, bc_type)

    case (JSPECTRAL)
       call compute_jspectral(psi, zeta, zj, NX, NY, dx, dy, bc_type)

    case (JENO4)
       call compute_jeno4(psi, zeta, zj, NX, NY, dx, dy, bc_type)

    case (JMFD4)
       call compute_jmfd4(psi, zeta, zj, NX, NY, dx, dy, bc_type)

    case default
       print *, 'ERRO arakawa_extended: esquema desconhecido =', ischeme
       stop
    end select

  end subroutine arakawa_compute

  !=============================================================================
  ! Diagnostics: energy and enstrophy
  !=============================================================================
  subroutine compute_energy_enstrophy(psi, zeta, NX, NY, dx, dy, bc_type, energy, enstrophy)
    integer, intent(in)  :: NX, NY, bc_type
    real, intent(in)     :: dx, dy
    real, intent(in)     :: psi(-1:NX+2, -1:NY+2), zeta(-1:NX+2, -1:NY+2)
    real, intent(out)    :: energy, enstrophy
    integer :: i, j
    real    :: psix, psiy, area

    energy    = 0.0
    enstrophy = 0.0
    area      = dx * dy

    do j = 1, NY
       do i = 1, NX
          psix = 0.5 * (access_val(psi, i+1, j, NX, NY, bc_type) - access_val(psi, i-1, j, NX, NY, bc_type)) / dx
          psiy = 0.5 * (access_val(psi, i, j+1, NX, NY, bc_type) - access_val(psi, i, j-1, NX, NY, bc_type)) / dy
          energy    = energy    + 0.5 * (psix**2 + psiy**2)
          enstrophy = enstrophy + 0.5 * zeta(i,j)**2
       end do
    end do

    energy    = energy    * area
    enstrophy = enstrophy * area
  end subroutine compute_energy_enstrophy

  !=============================================================================
  ! FFT init / cleanup (dummies for API compatibility)
  !=============================================================================
  subroutine fft_init(NX, NY)
    integer, intent(in) :: NX, NY
    ! No persistent state needed for iterative Cooley-Tukey
    fft_ready = .true.
    fft_nx_save = NX
    fft_ny_save = NY
  end subroutine fft_init

  subroutine fft_cleanup()
    if (allocated(fft_wk1)) deallocate(fft_wk1)
    if (allocated(fft_wk2)) deallocate(fft_wk2)
    if (allocated(fft_bitrev)) deallocate(fft_bitrev)
    if (allocated(fft_omega)) deallocate(fft_omega)
    fft_ready = .false.
    fft_nx_save = 0
    fft_ny_save = 0
  end subroutine fft_cleanup

end module arakawa_extended
!===============================================================================
