program test_all
  use arakawa_extended
  implicit none
  integer :: n
  print *, '#### 1) CONVERGENCIA: periodico, psi = sin x sin y + 0.5 sin(2x+0.7) cos y, L=2pi'
  print '(A)', ' esquema                                   N=16        N=32        N=64       N=128    | ordem(32->64) alpha(N=64)'
  call conv_all()
  print *
  print *, '#### 2) CANAL (BC_CHANNEL) NX=64 NY=32 dx=dy=1: campo que se anula nas paredes'
  call channel_test()
  print *
  print *, '#### 3) CONSERVACAO (campos aleatorios, periodico 64x32): sum(J), sum(psi*J), sum(zeta*J) / sum|.|'
  call cons_test()
contains
  subroutine fields_per(N, psi, zeta, jex, dx)
    integer, intent(in) :: N
    real, allocatable, intent(out) :: psi(:,:), zeta(:,:), jex(:,:)
    real, intent(out) :: dx
    real(8) :: pi, x, y, p1, p2, px, py, zx, zy
    integer :: i, j
    pi = 4.d0*atan(1.d0)
    allocate(psi(-1:N+2,-1:N+2), zeta(-1:N+2,-1:N+2), jex(N,N))
    psi = 0.; zeta = 0.
    dx = real(2.d0*pi/N)
    do j=1,N; do i=1,N
      x = (i-1)*2.d0*pi/N; y = (j-1)*2.d0*pi/N
      p1 = sin(x)*sin(y); p2 = 0.5d0*sin(2*x+0.7d0)*cos(y)
      psi(i,j) = real(p1+p2); zeta(i,j) = real(-2.d0*p1 - 5.d0*p2)
      px = cos(x)*sin(y) + cos(2*x+0.7d0)*cos(y)
      py = sin(x)*cos(y) - 0.5d0*sin(2*x+0.7d0)*sin(y)
      zx = -2.d0*cos(x)*sin(y) - 5.d0*cos(2*x+0.7d0)*cos(y)
      zy = -2.d0*sin(x)*cos(y) + 2.5d0*sin(2*x+0.7d0)*sin(y)
      jex(i,j) = real(px*zy - py*zx)
    end do; end do
    call boundary_fill_2layers(psi,N,N,BC_PERIODIC)
    call boundary_fill_2layers(zeta,N,N,BC_PERIODIC)
  end subroutine
  subroutine conv_all()
    integer :: ns(4) = (/16,32,64,128/), k, isch, N
    real, allocatable :: psi(:,:), zeta(:,:), jex(:,:), zj(:,:)
    real :: dx, err(4), al64
    real(8) :: e, en, a, d
    character(len=50) :: nm
    integer :: i, j
    do isch = 1, N_SCHEMES
      do k = 1, 4
        N = ns(k)
        call fields_per(N, psi, zeta, jex, dx)
        allocate(zj(N,N))
        call arakawa_compute(psi,zeta,zj,isch,N,N,dx,dx,BC_PERIODIC)
        e=0; en=0; a=0; d=0
        do j=1,N; do i=1,N
          e = e + (zj(i,j)-jex(i,j))**2; en = en + jex(i,j)**2
          a = a + zj(i,j)*jex(i,j); d = d + jex(i,j)**2
        end do; end do
        err(k) = real(sqrt(e/en))
        if (k==3) al64 = real(a/d)
        deallocate(zj, psi, zeta, jex)
      end do
      nm = arakawa_scheme_name(isch)
      print '(I3,1X,A32,4(1X,ES11.3),A,F7.2,3X,F8.4)', isch, nm(1:32), err, ' |', log(err(2)/err(3))/log(2.), al64
    end do
  end subroutine
  subroutine channel_test()
    integer, parameter :: NX=64, NY=32
    real :: psi(-1:NX+2,-1:NY+2), zeta(-1:NX+2,-1:NY+2), zj(NX,NY), jex(NX,NY)
    real(8) :: pi,x,y,a1,a2,kx1,ly1,kx2,ly2,p1,p2,px,py,zx,zy,c1,c2,eint,enorm,eall,nall,al,den
    integer :: isch,i,j
    character(len=50) :: nm
    pi=4.d0*atan(1.d0); a1=1.d0; a2=.5d0
    kx1=2*pi/NX; ly1=pi/(NY+1); kx2=2*pi*2/NX; ly2=pi*3/(NY+1)
    c1=kx1**2+ly1**2; c2=kx2**2+ly2**2
    psi=0.; zeta=0.
    do j=1,NY; do i=1,NX
      x=(i-1)*1.d0; y=j*1.d0
      p1=a1*sin(kx1*x)*sin(ly1*y); p2=a2*sin(kx2*x)*sin(ly2*y)
      psi(i,j)=real(p1+p2); zeta(i,j)=real(-c1*p1-c2*p2)
      px=a1*kx1*cos(kx1*x)*sin(ly1*y)+a2*kx2*cos(kx2*x)*sin(ly2*y)
      py=a1*ly1*sin(kx1*x)*cos(ly1*y)+a2*ly2*sin(kx2*x)*cos(ly2*y)
      zx=-c1*a1*kx1*cos(kx1*x)*sin(ly1*y)-c2*a2*kx2*cos(kx2*x)*sin(ly2*y)
      zy=-c1*a1*ly1*sin(kx1*x)*cos(ly1*y)-c2*a2*ly2*sin(kx2*x)*cos(ly2*y)
      jex(i,j)=real(px*zy-py*zx)
    end do; end do
    call boundary_fill_2layers(psi,NX,NY,BC_CHANNEL); call boundary_fill_2layers(zeta,NX,NY,BC_CHANNEL)
    print '(A)', ' esquema                                 err_rel(j=3..NY-2)   err_rel(todas as linhas)   alpha(interior)'
    do isch=1,N_SCHEMES
      call arakawa_compute(psi,zeta,zj,isch,NX,NY,1.,1.,BC_CHANNEL)
      eint=0;enorm=0;eall=0;nall=0;al=0;den=0
      do j=1,NY; do i=1,NX
        eall=eall+(zj(i,j)-jex(i,j))**2; nall=nall+jex(i,j)**2
        if (j>=3 .and. j<=NY-2) then
          eint=eint+(zj(i,j)-jex(i,j))**2; enorm=enorm+jex(i,j)**2
          al=al+zj(i,j)*jex(i,j); den=den+jex(i,j)**2
        end if
      end do; end do
      nm=arakawa_scheme_name(isch)
      print '(I3,1X,A32,2(8X,ES11.3),8X,F8.4)', isch, nm(1:32), sqrt(eint/enorm), sqrt(eall/nall), al/den
    end do
  end subroutine
  subroutine cons_test()
    integer, parameter :: NX=64, NY=32
    real :: psi(-1:NX+2,-1:NY+2), zeta(-1:NX+2,-1:NY+2), zj(NX,NY), r(NX,NY)
    real(8) :: s1,s2,s3,a1,a2,a3
    integer :: isch,i,j
    character(len=50) :: nm
    psi=0.; zeta=0.
    call random_number(r); psi(1:NX,1:NY)=r-.5
    call random_number(r); zeta(1:NX,1:NY)=r-.5
    call boundary_fill_2layers(psi,NX,NY,BC_PERIODIC); call boundary_fill_2layers(zeta,NX,NY,BC_PERIODIC)
    print '(A)', ' esquema                                       sum(J)      sum(psi*J)    sum(zeta*J)'
    do isch=1,N_SCHEMES
      call arakawa_compute(psi,zeta,zj,isch,NX,NY,1.,1.,BC_PERIODIC)
      s1=0;s2=0;s3=0;a1=0;a2=0;a3=0
      do j=1,NY; do i=1,NX
        s1=s1+zj(i,j); a1=a1+abs(zj(i,j))
        s2=s2+psi(i,j)*zj(i,j); a2=a2+abs(psi(i,j)*zj(i,j))
        s3=s3+zeta(i,j)*zj(i,j); a3=a3+abs(zeta(i,j)*zj(i,j))
      end do; end do
      nm=arakawa_scheme_name(isch)
      print '(I3,1X,A32,3(3X,ES11.2))', isch, nm(1:32), s1/a1, s2/a2, s3/a3
    end do
  end subroutine
end program
