!===============================================================================
! Modelo Barotropico Estendido ? 14 esquemas de Jacobiano
!===============================================================================
! Baseado no baro.f90 original, modificado para:
!   - Usar o modulo arakawa_extended (14 esquemas)
!   - Arrays com 2 camadas de ghost cells (-1:NX+2, -1:NY+2)
!   - Rodar todos os esquemas em sequencia com comparacao
!   - Diagnosticos de energia e enstrofia
!
! COMPILACAO:
!   gfortran -O2 arakawa_extended.f90 baro_extended.f90 -o baro_extended
!
! USO:
!   ./baro_extended              (modo 'all': roda todos os 14 esquemas)
!   ./baro_extended single 4     (modo 'single', esquema JARA)
!   ./baro_extended single 12    (modo 'single', esquema espectral)
!===============================================================================

!===============================================================================
! MODULE baromod ? arrays com 2 camadas de ghost cells
!===============================================================================
      module baromod
      use arakawa_extended
      implicit none
!
!     a) constants:
      integer,parameter :: NX = 64
      integer,parameter :: NY = 32
      real,parameter :: radea = 6.371E6
      real,parameter :: omega = 0.00007292
!
      integer :: nrun     = 240
      integer :: nout     = 1
!
      real :: rlat    = 50.
      real :: xchannel= 360.
      real :: ychannel= 40.
      real :: delt    = 1200.
!
!     b) variables ? arrays com 2 camadas de ghost cells
      integer :: nstep    = 0
      integer :: nwout    = 0
!
      real :: s(-1:NX+2,-1:NY+2)   = 0.
      real :: sm(-1:NX+2,-1:NY+2)  = 0.
      real :: dsdt(-1:NX+2,-1:NY+2)= 0.
      real :: vo(-1:NX+2,-1:NY+2)  = 0.
!
!     Copias para reinicializar entre esquemas
      real :: s_save(-1:NX+2,-1:NY+2)   = 0.
      real :: sm_save(-1:NX+2,-1:NY+2)  = 0.
      real :: vo_save(-1:NX+2,-1:NY+2)  = 0.
!
      real :: pi
      real :: beta
      real :: dx
      real :: dy
      real :: rossby
      real :: f0
      real :: delt2
!
!     Controle de esquema
      integer :: ischeme = JARA
      character(len=10) :: run_mode = 'all'
      character(len=50) :: scheme_name = ''
!
!     Condicao de contorno (padrao: canal = periodico X, parede Y)
      integer :: bc_type = BC_CHANNEL
!
!     Diagnosticos
      real :: total_energy    = 0.
      real :: total_enstrophy = 0.
      real :: energy_ini      = 0.
      real :: enstrophy_ini   = 0.
!
      end module baromod
!
!===============================================================================
! PROGRAM baro
!===============================================================================
      program baro
      use baromod
      implicit none
      integer :: iarg
      character(len=10) :: arg
!
      iarg = command_argument_count()
      if (iarg >= 1) then
         call get_command_argument(1, arg)
         run_mode = trim(arg)
      end if
      if (iarg >= 2 .and. run_mode == 'single') then
         call get_command_argument(2, arg)
         read(arg, *) ischeme
      end if
!
      if (ischeme < 1 .or. ischeme > N_SCHEMES) then
         print *, 'ERRO: ischeme deve estar entre 1 e', N_SCHEMES
         stop
      end if
!
      if (run_mode == 'single') then
         call run_single_scheme(ischeme)
      else
         call run_all_schemes
      end if
!
      print *, '============================================================'
      print *, '  MODELO BAROTROPICO ? TODOS OS ESQUEMAS CONCLUIDOS'
      print *, '============================================================'
!
      stop
      end program baro
!
!===============================================================================
! Rodar um unico esquema
!===============================================================================
      subroutine run_single_scheme(ischeme_in)
      use baromod
      implicit none
      integer, intent(in) :: ischeme_in
      integer :: jstep
!
      ischeme = ischeme_in
      scheme_name = arakawa_scheme_name(ischeme)
!
      print *, '============================================================'
      print *, '  RODANDO ESQUEMA:', ischeme, '-', trim(scheme_name)
      print *, '============================================================'
!
      call baroini
!
      s_save  = s
      sm_save = sm
      vo_save = vo
!
      call compute_energy_enstrophy(s, vo, NX, NY, dx, dy, bc_type, &
                                    total_energy, total_enstrophy)
      energy_ini    = total_energy
      enstrophy_ini = total_enstrophy
!
      print *, 'Energia inicial   =', energy_ini
      print *, 'Enstrofia inicial =', enstrophy_ini
!
      do jstep = 1, nrun
         call barostep
         nstep = nstep + 1
         if (mod(nstep, nout) == 0) call baroout
      end do
!
      call compute_energy_enstrophy(s, vo, NX, NY, dx, dy, bc_type, &
                                    total_energy, total_enstrophy)
      print *, 'Energia final     =', total_energy
      print *, 'Enstrofia final   =', total_enstrophy
      print *, 'Delta energia     =', total_energy    - energy_ini ,' =',1.0 - abs(total_energy    - energy_ini   )/energy_ini
      print *, 'Delta enstrofia   =', total_enstrophy - enstrophy_ini,' =',1.0 - abs(total_enstrophy - enstrophy_ini)/energy_ini
!
      call barostop
!
      return
      end subroutine run_single_scheme
!
!===============================================================================
! Rodar todos os esquemas em sequencia
!===============================================================================
      subroutine run_all_schemes
      use baromod
      implicit none
      integer :: isch,jstep
      real :: energy_final(N_SCHEMES), enstrophy_final(N_SCHEMES)
      real :: denergy(N_SCHEMES), denstrophy(N_SCHEMES)
      character(len=50) :: sname
!
      print *, '============================================================'
      print *, '  MODO: RODANDO TODOS OS', N_SCHEMES, 'ESQUEMAS DE JACOBIANO'
      print *, '============================================================'
!
      call baroini_base
!
      s_save  = s
      sm_save = sm
      vo_save = vo
      call compute_energy_enstrophy(s, vo, NX, NY, dx, dy, bc_type, &
                                    energy_ini, enstrophy_ini)
!
      print *, 'Condicao inicial:'
      print *, '  Energia inicial   =', energy_ini
      print *, '  Enstrofia inicial =', enstrophy_ini
!
      do isch = 1, N_SCHEMES
!
         print *, ' '
         print *, '------------------------------------------------------------'
         sname = arakawa_scheme_name(isch)
         print *, '>>> Esquema', isch, ':', trim(sname)
         print *, '------------------------------------------------------------'
!
         s  = s_save
         sm = sm_save
         vo = vo_save
         nstep = 0
         nwout = 0
         ischeme = isch
         scheme_name = sname
!
         call open_output_for_scheme(isch)
         call baroout
!
         do jstep = 1, nrun
            call barostep
            nstep = nstep + 1
            if (mod(nstep, nout) == 0) call baroout
            if(jstep==1)then
               call compute_energy_enstrophy(s, vo, NX, NY, dx, dy, bc_type, &
                                    energy_ini, enstrophy_ini)
!
               print *, 'Condicao inicial:'
               print *, '  Energia inicial   =', energy_ini
               print *, '  Enstrofia inicial =', enstrophy_ini
            end if
         end do
!
         call compute_energy_enstrophy(s, vo, NX, NY, dx, dy, bc_type, &
                                       total_energy, total_enstrophy)
         energy_final(isch)    = total_energy
         enstrophy_final(isch) = total_enstrophy
         denergy(isch)         = total_energy    - energy_ini
         denstrophy(isch)      = total_enstrophy - enstrophy_ini
!
         print *, '  Energia final   =', energy_final(isch)
         print *, '  Enstrofia final =', enstrophy_final(isch)
         print *, '  Delta energia   =', denergy(isch),   ' =', abs(total_energy    - energy_ini)/energy_ini,'%'
         print *, '  Delta enstrofia =', denstrophy(isch),' =', abs(total_enstrophy - enstrophy_ini)/energy_ini,'%'
!
         call close_output
!
      end do
!
!     Tabela comparativa
      print *, ' '
      print *, '============================================================'
      print *, '  TABELA COMPARATIVA ? TODOS OS ESQUEMAS'
      print *, '============================================================'
      print *, 'ID  Nome do esquema                              Delta(E)      Delta(G)'
      print *, '--- -------------------------------------------- ------------- -------------'
      do isch = 1, N_SCHEMES
         sname = arakawa_scheme_name(isch)
         print '(I2,2X,A46,2(2X,ES12.4))', isch, trim(sname), &
               denergy(isch), denstrophy(isch)
      end do
      print *, '--- -------------------------------------------- ------------- -------------'
      print *, 'Legenda: Delta(E) = energia final - energia inicial'
      print *, '         Delta(G) = enstrofia final - enstrofia inicial'
      print *, '         Valores proximos de zero = boa conservacao'
      print *, '============================================================'
!
      return
      end subroutine run_all_schemes
!
!===============================================================================
! Inicializacao base
!===============================================================================
      subroutine baroini_base
      use baromod
      implicit none
      real :: zlat, zxch, zych, zdelt
      integer :: kits, js
!
      pi   = 2. * asin(1.)
      zlat = pi * rlat / 180.
      zxch = pi * radea * cos(zlat) * xchannel / 180.
      zych = pi * radea * ychannel / 180.
      dx   = zxch / real(NX)
      dy   = zych / real(NY + 1)
      f0   = 2. * omega * sin(zlat)
      beta = 2. * omega * cos(zlat) / radea
      delt2 = 2. * delt
!
      print *, ' f0       = ', f0
      print *, ' beta     = ', beta
      print *, ' delta x  = ', dx
      print *, ' delta y  = ', dy
      print *, ' Rossby Cp   = ', beta * zxch * zxch / (2. * pi)**2
      print *, ' Rossby C-No = ', (beta * zxch * zxch / (2. * pi)**2) * delt / dx
!
      call initial
!
      kits  = 3
      zdelt = delt / 2**kits
      do js = 1, kits
         zdelt = zdelt + zdelt
         call mkvort(s, vo, dx, dy, NX, NY)
         call tendency
         call euler(sm, dsdt, s, zdelt, NX, NY)
         call boundary_fill(s)
      end do
!
      return
      end subroutine baroini_base
!
!===============================================================================
! Inicializacao completa
!===============================================================================
      subroutine baroini
      use baromod
      implicit none
      character(len=20) :: outfile
!
      call baroini_base
      outfile = 'barogp'
      open(10, file=outfile, form='unformatted', status='unknown', action='WRITE')
!
      return
      end subroutine baroini
!
!===============================================================================
! Time step
!===============================================================================
      subroutine barostep
      use baromod
      implicit none
!
      call mkvort(s, vo, dx, dy, NX, NY)
      call tendency
      call leapfrog(s, sm, dsdt, delt2, NX, NY)
      call boundary_fill(s)
!
      return
      end subroutine barostep
!
!===============================================================================
! Tendency ? usa arakawa_compute do modulo
!===============================================================================
      subroutine tendency
      use baromod
      implicit none
      real :: zdt(-1:NX+2,-1:NY+2)
      real :: zj(-1:NX+2,-1:NY+2)
      real :: zv(-1:NX+2,-1:NY+2)
      real :: zj_out(NX,NY)
      integer :: i, j
!
!     Preencher ghost cells antes do Jacobiano
      call boundary_fill(s)
      call boundary_fill(vo)
!
!     Calcular Jacobiano com o esquema selecionado
      call arakawa_compute(s, vo, zj_out, ischeme, NX, NY, dx, dy, bc_type)
!
!     Copiar resultado para array com ghost cells
      zj = 0.
      do j = 1, NY
         do i = 1, NX
            zj(i,j) = zj_out(i,j)
         end do
      end do
!
!     Preencher ghost cells do Jacobiano
      call boundary_fill(zj)
!
!     d(psi)/dx para beta-term
      call mkdfdx(s, zv, dx, NX, NY)
      call boundary_fill(zv)
!
!     Tendencia de vorticidade
      zdt = -zj - beta * zv
      call boundary_fill(zdt)
!
!     Inverter Laplaciano para obter tendencia de streamfunction
      call sor(zdt, dsdt, dx, dy, NX, NY)
      call boundary_fill(dsdt)
!
      return
      end subroutine tendency
!
!===============================================================================
! Boundary fill ? preenche 2 camadas de ghost cells
!===============================================================================
      subroutine boundary_fill(f)
      use baromod
      implicit none
      real :: f(-1:NX+2,-1:NY+2)
      call boundary_fill_2layers(f, NX, NY, bc_type)
      return
      end subroutine boundary_fill
!
!===============================================================================
! Output
!===============================================================================
      subroutine baroout
      use baromod
      implicit none
      real :: zu(NX,NY), zv(NX,NY)
!
      call mkuv(s, zu, zv, dx, dy, NX, NY)
      write(10) zu(1:NX,1:NY)
      write(10) zv(1:NX,1:NY)
      write(10) s(1:NX,1:NY)
      write(10) s(1:NX,1:NY) * f0 / 9.81
      write(10) vo(1:NX,1:NY)
      nwout = nwout + 1
!
      return
      end subroutine baroout
!
!===============================================================================
! Finalizacao
!===============================================================================
      subroutine barostop
      use baromod
      implicit none
      close(10)
      call gradsinfo
      print *, '****************************************************'
      print *, 'Run finished at nstep= ', nstep
      print *, 'Esquema usado: ', trim(scheme_name)
      print *, '****************************************************'
      return
      end subroutine barostop
!
!===============================================================================
! Abrir arquivo de saida por esquema
!===============================================================================
      subroutine open_output_for_scheme(isch)
      use baromod
      implicit none
      integer, intent(in) :: isch
      character(len=20) :: fname
      write(fname, '(A,I2.2)') 'barogp_', isch
      open(10, file=fname, form='unformatted', status='unknown', action='WRITE')
      print *, '  Arquivo de saida:', trim(fname)
      return
      end subroutine open_output_for_scheme
!
!===============================================================================
! Fechar arquivo
!===============================================================================
      subroutine close_output
      implicit none
      close(10)
      return
      end subroutine close_output
!
!===============================================================================
! GrADS info
!===============================================================================
      subroutine gradsinfo
      use baromod
      implicit none
      integer :: isch
      character(len=20) :: ctlfile, datfile
      real :: zy1, zdy
!
      if (run_mode == 'all') then
         do isch = 1, N_SCHEMES
            write(datfile, '(A,I2.2)') 'barogp_', isch
            write(ctlfile, '(A,I2.2,A)') 'barogp_', isch, '.ctl'
            open(10, file=ctlfile, form='formatted')
            zdy = ychannel / real(NY + 1)
            zy1 = rlat - ychannel / 2. + zdy
            write(10,1) 'DSET ^'//trim(datfile)
            write(10,1) 'UNDEF 9E+09'
            write(10,1) 'OPTIONS SEQUENTIAL'
            write(10,2) 'XDEF ', NX, ' LINEAR ', 0., ' ', xchannel / real(NX)
            write(10,2) 'YDEF ', NY, ' LINEAR ', zy1, ' ', zdy
            write(10,1) 'ZDEF 1 LINEAR 1 1'
            write(10,3) 'TDEF ', nwout, ' LINEAR 00:00Z01jan0001 20mn'
            write(10,1) 'VARS 5'
            write(10,1) 'U 0 99 zonal velocity'
            write(10,1) 'V 0 99 meridional velocity'
            write(10,1) 'S 0 99 streamfunction'
            write(10,1) 'Z 0 99 geopotential height'
            write(10,1) 'VO 0 99 vorticity'
            write(10,1) 'ENDVARS'
            close(10)
         end do
      else
         open(10, file='barogp.ctl', form='formatted')
         zdy = ychannel / real(NY + 1)
         zy1 = rlat - ychannel / 2. + zdy
         write(10,1) 'DSET ^barogp'
         write(10,1) 'UNDEF 9E+09'
         write(10,1) 'OPTIONS SEQUENTIAL'
         write(10,2) 'XDEF ', NX, ' LINEAR ', 0., ' ', xchannel / real(NX)
         write(10,2) 'YDEF ', NY, ' LINEAR ', zy1, ' ', zdy
         write(10,1) 'ZDEF 1 LINEAR 1 1'
         write(10,3) 'TDEF ', nwout, ' LINEAR 00:00Z01jan0001 20mn'
         write(10,1) 'VARS 5'
         write(10,1) 'U 0 99 zonal velocity'
         write(10,1) 'V 0 99 meridional velocity'
         write(10,1) 'S 0 99 streamfunction'
         write(10,1) 'Z 0 99 geopotential height'
         write(10,1) 'VO 0 99 vorticity'
         write(10,1) 'ENDVARS'
         close(10)
      end if
!
    1 format(A)
    2 format(A,I5,A,F10.5,A,F10.5)
    3 format(A,I5,A)
      return
      end subroutine gradsinfo
!
!===============================================================================
! Condicao inicial
!===============================================================================
!===============================================================================
! Condicao inicial ? varias opcoes
!   icond = 1 : onda senoidal pura (linear, J=0) ? PADRAO do baro.f90
!   icond = 2 : vortice gaussiano localizado (nao-linear, J /= 0)
!   icond = 3 : superposicao de 2 modos (interacao nao-linear)
!===============================================================================
      subroutine initial
      use baromod
      implicit none
      real :: za, zk, zl, x, y, x0, y0, sigma
      integer :: i, j, icond
!
!     Escolha a condicao inicial (1, 2, ou 3)
      icond = 2   ! <--- MUDE AQUI: 1=onda, 2=vortice, 3=multi-modo
!
      if (icond == 1) then
!        --- Condicao inicial padrao (onda senoidal pura) ---
!        Nota: J(psi,zeta) = 0 exatamente para esta CI (proporcional)
         za = 10. * 1.E6
         zk = 1.
         zl = 0.5
         do j = 1, NY
            do i = 1, NX
               s(i,j) = za * sin(2. * pi * real(i-1) * zk / real(NX)) &
     &                  * sin(2. * pi * real(j) * zl / real(NY+1))
            end do
         end do
!
      else if (icond == 2) then
!        --- Vortice gaussiano localizado (nao-linear) ---
!        J(psi,zeta) /= 0 porque psi e zeta NAO sao proporcionais
         za = 8. * 1.E6
         x0 = real(NX) / 2.          ! centro em X
         y0 = real(NY) / 2.          ! centro em Y
         sigma = real(NX) / 8.       ! largura do vortice
         do j = 1, NY
            do i = 1, NX
               x = real(i-1)
               y = real(j)
               s(i,j) = za * exp(-((x-x0)**2 + (y-y0)**2) / (2.*sigma**2))
            end do
         end do
!
      else if (icond == 3) then
!        --- Superposicao de 2 modos (interacao nao-linear) ---
!        J(psi,zeta) /= 0 porque ha mais de um modo interagindo
         za = 6. * 1.E6
         do j = 1, NY
            do i = 1, NX
               s(i,j) = za * ( sin(2.*pi*real(i-1)/real(NX)) * sin(2.*pi*real(j)*0.5/real(NY+1)) &
     &                       + 0.5 * sin(2.*pi*real(i-1)*2./real(NX)) * sin(2.*pi*real(j)*1.0/real(NY+1)) )
            end do
         end do
!
      end if
!
      call boundary_fill(s)
      sm = s
      call mkvort(s, vo, dx, dy, NX, NY)
      call baroout
      return
      end subroutine initial
!
!===============================================================================
! Subrotinas originais (adaptadas para ghost cells -1:NX+2)
!===============================================================================
      subroutine mkuv(ps,pu,pv,pdx,pdy,kx,ky)
      implicit none
      integer :: kx, ky
      real :: pdx, pdy
      real :: ps(-1:kx+2,-1:ky+2)
      real :: pu(kx,ky), pv(kx,ky)
      integer :: i, j
      do j = 1, ky
         do i = 1, kx
            pu(i,j) = -0.5 * (ps(i,j+1) - ps(i,j-1)) / pdy
            pv(i,j) =  0.5 * (ps(i+1,j) - ps(i-1,j)) / pdx
         end do
      end do
      return
      end subroutine mkuv
!
      subroutine mkvort(ps,pvo,pdx,pdy,kx,ky)
      use baromod, only : bc_type
      use arakawa_extended, only : boundary_fill_2layers
      implicit none
      integer :: kx, ky
      real :: pdx, pdy
      real :: ps(-1:kx+2,-1:ky+2)
      real :: pvo(-1:kx+2,-1:ky+2)
      call laplace(ps, pvo, pdx, pdy, kx, ky)
      call boundary_fill_2layers(pvo, kx, ky, bc_type)
      return
      end subroutine mkvort
!
      subroutine mkdfdx(pf,pdfdx,pdx,kx,ky)
      implicit none
      integer :: kx, ky
      real :: pdx
      real :: pf(-1:kx+2,-1:ky+2)
      real :: pdfdx(-1:kx+2,-1:ky+2)
      integer :: i, j
      real :: zx
      zx = 1. * pdx
      do j = 1, ky
         do i = 1, kx
            pdfdx(i,j) = (pf(i+1,j) - pf(i,j)) / zx
         end do
      end do
      return
      end subroutine mkdfdx
!
      subroutine laplace(pf,pdf,pdx,pdy,kx,ky)
      implicit none
      integer :: kx, ky
      real :: pdx, pdy
      real :: pf(-1:kx+2,-1:ky+2)
      real :: pdf(-1:kx+2,-1:ky+2)
      integer :: i, j
      do j = 1, ky
         do i = 1, kx
            pdf(i,j) = (pf(i-1,j) - 2.*pf(i,j) + pf(i+1,j)) / (pdx*pdx) &
     &               + (pf(i,j-1) - 2.*pf(i,j) + pf(i,j+1)) / (pdy*pdy)
         end do
      end do
      return
      end subroutine laplace
!
      subroutine euler(pfm,pdfdt,pf,pdelt,kx,ky)
      implicit none
      integer :: kx, ky
      real :: pdelt
      real :: pfm(-1:kx+2,-1:ky+2)
      real :: pdfdt(-1:kx+2,-1:ky+2)
      real :: pf(-1:kx+2,-1:ky+2)
      pf(1:kx,1:ky) = pfm(1:kx,1:ky) + pdelt * pdfdt(1:kx,1:ky)
      return
      end subroutine euler
!
      subroutine leapfrog(pf,pfm,pdfdt,pdelt2,kx,ky)
      implicit none
      real, parameter :: gamma = 0.01
      integer :: kx, ky
      real :: pdelt2
      real :: pf(-1:kx+2,-1:ky+2)
      real :: pfm(-1:kx+2,-1:ky+2)
      real :: pdfdt(-1:kx+2,-1:ky+2)
      real :: zsp(-1:kx+2,-1:ky+2)
      zsp = pfm + pdelt2 * pdfdt
      pfm = pf + gamma * (pfm - 2.*pf + zsp)
      pf  = zsp
      return
      end subroutine leapfrog
!
      subroutine sor(pdf,pf,pdx,pdy,kx,ky)
      use baromod, only : bc_type
      use arakawa_extended, only : boundary_fill_2layers
      implicit none
      real, parameter :: wsor = 1.50, eps = 1.E-6
      integer :: kx, ky, niter, i, j, jiter
      real :: pdx, pdy
      real :: pdf(-1:kx+2,-1:ky+2)
      real :: pf(-1:kx+2,-1:ky+2)
      real :: zn(-1:kx+2,-1:ky+2), zo(-1:kx+2,-1:ky+2)
      real :: zfac, zzres, zresf, zres
      niter = ky * kx * nint(log10(1./eps) + 0.5) / 3
      zfac = 2./(pdx*pdx) + 2./(pdy*pdy)
      zn = 0.
      zresf = 0.
      do j = 1, ky
         do i = 1, kx
            zzres = -zfac*zn(i,j) + (zn(i-1,j)+zn(i+1,j))/(pdx*pdx) &
     &            + (zn(i,j-1)+zn(i,j+1))/(pdy*pdy) - pdf(i,j)
            zresf = zresf + abs(zzres) / real(kx*ky)
         end do
      end do
      do jiter = 1, niter
         zo = zn
         zres = 0.
         do j = 1, ky
            do i = 1, kx
               zzres = -zfac*zo(i,j) + (zn(i-1,j)+zo(i+1,j))/(pdx*pdx) &
     &               + (zn(i,j-1)+zo(i,j+1))/(pdy*pdy) - pdf(i,j)
               zn(i,j) = zo(i,j) + wsor * zzres / zfac
               zres = zres + abs(zzres) / real(kx*ky)
            end do
         end do
         call boundary_fill_2layers(zn, kx, ky, bc_type)
         if (zres <= eps * zresf) exit
      end do
      !if (jiter >= niter) then
      !   print *, 'MAXIMUM iterations needed', niter
      !   print *, 'error, initial error, eps*ie= ', zres, zresf, eps*zresf
      !end if
      pf = zn
      return
      end subroutine sor
!===============================================================================
