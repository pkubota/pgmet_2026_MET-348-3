#!/bin/sh
# Roda OI, KF, EnKF e 4D-Var no cenario "da_dfi.nml" com e sem DFI e gera cenario_dfi.png
set -e
make -s MODE=opt all
for modo in sem_dfi com_dfi; do
  mkdir -p cen_$modo
  if [ $modo = sem_dfi ]; then sed 's/use_dfi = .true./use_dfi = .false./' da_dfi.nml > cen_$modo/da.nml
  else cp da_dfi.nml cen_$modo/da.nml; fi
  for p in oi kf enkf var4d; do (cd cen_$modo && ../$p.exe > $p.log); done
done
python3 plot_cenario_dfi.py
