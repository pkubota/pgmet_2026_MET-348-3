!======================================================================
! Modulo/Programa : var3d_advec_diff  -  3D-Var ciclado
!   J(dx) = 1/2 dx^T B^-1 dx + 1/2 (d - H dx)^T R^-1 (d - H dx)
! Variavel de controle  dx = L v  (B = L L^T)  ->  J(v) = 1/2 v^T v + ...
! Minimizacao por gradiente conjugado:  (I + Hl^T Hl / sig_o^2) v = Hl^T d / sig_o^2
! com Hl = H L.  Verificacao: resultado deve coincidir com a OI.
!======================================================================
module var3d_mod
  use da_mod
  implicit none
  real(rk), allocatable :: Hl(:,:)       ! H L  (nobs x nx)
contains
  function hess3d(v) result(av)
    real(rk), intent(in) :: v(:)
    real(rk) :: av(size(v))
    av = v + matmul(transpose(Hl), matmul(Hl, v))/sig_o**2
  end function hess3d
end module var3d_mod

program var3d_advec_diff
  use da_mod
  use var3d_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:)
  real(rk), allocatable :: xt(:), xfree(:), xb(:), xa(:), xa_oi(:)
  real(rk), allocatable :: B(:,:), LB(:,:), S(:,:), LS(:,:), w(:,:)
  real(rk), allocatable :: d(:), v(:), rhs(:)
  real(rk) :: Jb, Jo, J0, J1, maxdif
  integer :: n, i, j, k, nit, ncg

  call read_config(); call setup_obs()
  allocate(xt(nx), xfree(nx), xb(nx), xa(nx), xa_oi(nx), B(nx,nx), LB(nx,nx), &
           S(nobs,nobs), LS(nobs,nobs), w(nobs,1), d(nobs), v(nx), rhs(nx), Hl(nobs,nx))
  call make_experiment(xt_all, y_all)
  call build_cov(sig_b, lcorr, B)
  call chol_factor(B, LB)
  do k = 1, nobs
     Hl(k,:) = LB(iobs(k),:)                 ! H L = linhas de L nos pontos observados
  end do
  do j = 1, nobs                             ! S so para a comparacao com a OI
     do i = 1, nobs; S(i,j) = B(iobs(i),iobs(j)); end do
     S(j,j) = S(j,j) + sig_o**2
  end do
  call chol_factor(S, LS)

  call init_background(xb); xfree = xb; call dfi_state0(xb); xa = xb
  call open_outputs('var3d')
  call log_step(0, xt_all(:,0), xfree, xb, xa)
  maxdif = 0; ncg = 0; nit = 0

  do n = 1, nt
     xfree = model_step(xfree, u_model)
     xb    = model_step(xa,    u_model)
     if (mod(n, obs_every) == 0) then
        do k = 1, nobs; d(k) = y_all(k,n) - xb(iobs(k)); end do
        rhs = matmul(transpose(Hl), d)/sig_o**2
        call cg_solve(hess3d, rhs, v, 1.0e-10_rk, 200, nit)
        xa = xb + matmul(LB, v)
        ncg = ncg + nit
        ! custo antes/depois (so impresso na 1a analise)
        if (n == obs_every) then
           Jb = 0.5_rk*dot_product(v,v)
           Jo = 0.5_rk*sum((d - matmul(Hl,v))**2)/sig_o**2
           J0 = 0.5_rk*sum(d**2)/sig_o**2
           J1 = Jb + Jo
           write(*,'(A,I0,A)')       ' 1a analise (passo ', n, '):'
           write(*,'(A,ES11.4,A,ES11.4)') '   J(inicial) = ', J0, '   J(final) = ', J1
           write(*,'(A,ES11.4,A,ES11.4)') '   Jb = ', Jb, '   Jo = ', Jo
           write(*,'(A,I0)')         '   iteracoes do CG = ', nit
        end if
        ! verificacao contra OI (mesmo B e R => mesma analise)
        w(:,1) = d; w = chol_solve(LS, w)
        xa_oi = xb
        do k = 1, nobs; xa_oi = xa_oi + B(:,iobs(k))*w(k,1); end do
        maxdif = max(maxdif, maxval(abs(xa - xa_oi)))
        if (use_dfi) xa = dfi_init(xa, u_model)      ! DFI opcional (apos a comparacao)
     else
        xa = xb
     end if
     call log_step(n, xt_all(:,n), xfree, xb, xa)
  end do
  write(*,'(A,ES10.3)') ' max|xa(3D-Var) - xa(OI)| em todas as analises = ', maxdif
  write(*,'(A,F6.1)')   ' iteracoes medias do CG por analise = ', real(ncg)/(nt/obs_every)
  call close_outputs('var3d', '3D-Var com B gaussiana (ciclado)')
end program var3d_advec_diff
