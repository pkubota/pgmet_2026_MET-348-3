!======================================================================
! Modulo   : da_mod  -  infraestrutura comum dos experimentos de
!            assimilacao de dados (MET-348-3, PGMET)
! Conteudo : configuracao (namelist), modelo de advecao-difusao 1D
!            (periodico, upwind), Jacobiana, covariancias, observacoes
!            sinteticas (experimento de gêmeos idênticos), algebra linear,
!            gradiente conjugado, saida GrADS (.bin/.ctl) e RMSE.
!
! Equacao  :  dc/dt + (U + alpha*c) dc/dx = kappa d2c/dx2
!             alpha = 0  -> modelo linear  (OI, 3D-Var, KF)
!             alpha > 0  -> modelo nao linear (EKF, EnKF, 4D-Var)
!======================================================================
module da_mod
  use iso_fortran_env, only: real32, real64
  implicit none
  integer,  parameter :: rk = real64, sp = real32
  real(rk), parameter :: pi = 3.14159265358979323846_rk

  ! ------------------------- configuracao ---------------------------
  integer  :: nx = 50              ! pontos de grade (dominio periodico)
  integer  :: nt = 100             ! passos de tempo (100 passos = 1 volta)
  real(rk) :: dx = 1.0_rk, dt = 0.5_rk
  real(rk) :: u_true  = 1.0_rk     ! velocidade "verdadeira"
  real(rk) :: u_model = 0.8_rk     ! velocidade do modelo (erro de modelo)
  real(rk) :: kappa = 0.1_rk       ! difusividade
  real(rk) :: alpha = 0.3_rk       ! nao linearidade (0 = linear)
  real(rk) :: sig_o = 0.02_rk      ! desvio padrao do erro de observacao
  real(rk) :: sig_b = 0.04_rk      ! desvio padrao do erro de background
  real(rk) :: lcorr = 3.0_rk       ! comprimento de correlacao [pontos de grade]
  real(rk) :: sig_q = 0.02_rk      ! erro de modelo (KF/EKF/EnKF)
  integer  :: obs_stride = 5       ! observa 1 a cada obs_stride pontos
  integer  :: obs_every  = 5       ! assimila a cada obs_every passos
  integer  :: nwin = 10            ! janela do 4D-Var [passos]
  integer  :: nouter = 3           ! laços externos do 4D-Var incremental
  integer  :: nens = 20            ! membros do EnKF
  real(rk) :: infl = 1.05_rk       ! inflacao multiplicativa (EnKF)
  real(rk) :: loc_rad = 8.0_rk     ! raio de localizacao Gaspari-Cohn (<=0: sem)
  integer  :: seed0 = 12345
  ! --- Inicializacao por Filtro Digital (DFI, Dolph-Chebyshev, estilo HIRLAM) ---
  real(rk) :: pulse_w = 3.0_rk      ! largura (sigma) do pulso verdadeiro [pontos de grade]
  integer  :: pulse_shape = 0         ! forma do pulso: 0 = gaussiana, 1 = onda quadrada (mesma variancia)
  real(rk) :: noise_amp = 0.0_rk     ! ruido de alta frequencia (ondas 8dx-3dx) no background inicial
  logical  :: use_dfi  = .false.   ! aplica DFI a cada analise
  integer  :: dfi_M    = 5         ! N = 2M+1 pesos; janela TS = 2 M dt
  real(rk) :: dfi_tau  = 6.0_rk    ! periodo de corte [unidades de tempo do modelo]
  logical  :: dfi_diab = .false.   ! difusao no estagio 2 (variante diabatica)
  logical  :: dfi_init0 = .true.   ! tambem inicializa o estado inicial (passo 0)

  namelist /da_cfg/ nx, nt, dx, dt, u_true, u_model, kappa, alpha, sig_o, &
       sig_b, lcorr, sig_q, obs_stride, obs_every, nwin, nouter, nens,   &
       infl, loc_rad, seed0, use_dfi, dfi_M, dfi_tau, dfi_diab, dfi_init0, pulse_w, noise_amp, pulse_shape

  ! ----------------------------- observacoes ------------------------
  integer :: nobs = 0
  integer, allocatable :: iobs(:)

  ! ------------------------------ saida -----------------------------
  integer, parameter :: ugr = 21, urm = 22
  integer :: irec = 0, ntime = 0, nsum = 0
  real(rk) :: s_free = 0, s_b = 0, s_a = 0

  abstract interface
     function matvec_if(v) result(av)
       import :: rk
       real(rk), intent(in) :: v(:)
       real(rk) :: av(size(v))
     end function matvec_if
  end interface

contains
  !--------------------------------------------------------------------
  subroutine read_config()
    logical :: ex
    integer :: u
    character(len=256) :: fnml
    fnml = 'da.nml'
    if (command_argument_count() >= 1) call get_command_argument(1, fnml)
    inquire(file=trim(fnml), exist=ex)
    if (ex) then
       open(newunit=u, file=trim(fnml), status='old', action='read')
       read(u, nml=da_cfg)
       close(u)
       write(*,'(2A)') ' [config] lido de ', trim(fnml)
    else
       write(*,'(2A)') ' [config] nao encontrado: usando valores padrao: ', trim(fnml)
    end if
    if (mod(nt, obs_every) /= 0) stop 'erro: nt deve ser multiplo de obs_every'
    if (mod(nwin, obs_every) /= 0) stop 'erro: nwin deve ser multiplo de obs_every'
  end subroutine read_config

  subroutine setup_obs()
    integer :: k
    nobs = (nx + obs_stride - 1) / obs_stride
    if (allocated(iobs)) deallocate(iobs)
    allocate(iobs(nobs))
    do k = 1, nobs
       iobs(k) = 1 + (k-1)*obs_stride
    end do
  end subroutine setup_obs

  !--------------------------------------------------------------------
  ! Modelo: um passo de tempo (upwind + difusao centrada, periodico)
  !--------------------------------------------------------------------
  pure function model_step(c, u) result(cn)
    real(rk), intent(in) :: c(:), u
    real(rk) :: cn(size(c))
    integer :: i, n, im, ip
    real(rk) :: v, dif, a
    n = size(c); dif = kappa*dt/dx**2; a = dt/dx
    do i = 1, n
       im = i-1; if (i == 1) im = n
       ip = i+1; if (i == n) ip = 1
       v = u + alpha*c(i)
       if (v >= 0.0_rk) then
          cn(i) = c(i) - a*v*(c(i)-c(im)) + dif*(c(ip)-2*c(i)+c(im))
       else
          cn(i) = c(i) - a*v*(c(ip)-c(i)) + dif*(c(ip)-2*c(i)+c(im))
       end if
    end do
  end function model_step

  ! Jacobiana (modelo linearizado / tangente linear) em torno de c
  pure function model_jac(c, u) result(M)
    real(rk), intent(in) :: c(:), u
    real(rk) :: M(size(c), size(c))
    integer :: i, n, im, ip
    real(rk) :: v, dif, a
    n = size(c); dif = kappa*dt/dx**2; a = dt/dx
    M = 0.0_rk
    do i = 1, n
       im = i-1; if (i == 1) im = n
       ip = i+1; if (i == n) ip = 1
       v = u + alpha*c(i)
       if (v >= 0.0_rk) then
          M(i,i)  = 1 - a*(alpha*(c(i)-c(im)) + v) - 2*dif
          M(i,im) = a*v + dif
          M(i,ip) = dif
       else
          M(i,i)  = 1 - a*(alpha*(c(ip)-c(i)) - v) - 2*dif
          M(i,ip) = -a*v + dif
          M(i,im) = dif
       end if
    end do
  end function model_jac

  !--------------------------------------------------------------------
  ! Condicoes iniciais (pulso periodico: gaussiano ou onda quadrada)
  !--------------------------------------------------------------------
  subroutine pulse(c, x0, w, amp)
    real(rk), intent(out) :: c(:)
    real(rk), intent(in)  :: x0, w, amp
    integer :: i, n
    real(rk) :: d
    n = size(c)
    do i = 1, n
       d = abs(real(i-1,rk) - x0); d = min(d, n - d)
       if (pulse_shape == 1) then
          ! onda quadrada de mesma variancia que a gaussiana: largura L = 2*sqrt(3)*w;
          ! as bordas usam peso fracionario da celula (posicao sub-grade)
          c(i) = amp*max(0.0_rk, min(1.0_rk, sqrt(3.0_rk)*w - d + 0.5_rk))
       else
          c(i) = amp*exp(-0.5_rk*(d/w)**2)
       end if
    end do
  end subroutine pulse

  subroutine init_truth(c)
    real(rk), intent(out) :: c(:)
    call pulse(c, 0.24_rk*nx, pulse_w, 1.0_rk)
  end subroutine init_truth

  subroutine init_background(c)      ! pulso deslocado, mais largo e mais fraco
    real(rk), intent(out) :: c(:)
    integer :: i, m
    call pulse(c, 0.28_rk*nx, pulse_w + 1.0_rk, 0.7_rk)
    if (noise_amp > 0.0_rk) then            ! mesmo ruido deterministico do teste da DFI
       do m = nx/8, nx/3
          do i = 1, size(c)
             c(i) = c(i) + noise_amp*cos(2.0_rk*pi*m*real(i-1,rk)/size(c) &
                  + 2.0_rk*pi*modulo(m*0.6180339887498949_rk, 1.0_rk))
          end do
       end do
    end if
  end subroutine init_background

  !--------------------------------------------------------------------
  ! Verdade + observacoes sinteticas (identicas para todos os metodos)
  !--------------------------------------------------------------------
  subroutine make_experiment(xt_all, y_all)
    real(rk), allocatable, intent(out) :: xt_all(:,:), y_all(:,:)
    integer :: n, k
    allocate(xt_all(nx,0:nt), y_all(nobs,0:nt))
    call seed_rng(seed0)
    call init_truth(xt_all(:,0))
    y_all = -9999.0_rk
    do n = 1, nt
       xt_all(:,n) = model_step(xt_all(:,n-1), u_true)
       if (mod(n, obs_every) == 0) then
          do k = 1, nobs
             y_all(k,n) = xt_all(iobs(k),n) + sig_o*randn()
          end do
       end if
    end do
  end subroutine make_experiment

  !--------------------------------------------------------------------
  ! Covariancias: C_ij = sig^2 sum_imagens exp(-d^2/(2 L^2)) + nugget (periodica)
  !--------------------------------------------------------------------
  subroutine build_cov(sig, L, C)
    real(rk), intent(in)  :: sig, L
    real(rk), intent(out) :: C(:,:)
    real(rk), parameter :: nugget = 1.0e-4_rk
    integer :: i, j, n
    real(rk) :: d
    n = size(C,1)
    do j = 1, n
       do i = 1, n
          d = real(i-j,rk)                  ! gaussiana periodizada (soma de imagens):
          C(i,j) = sig**2*( exp(-0.5_rk*(d/L)**2) + exp(-0.5_rk*((d-n)/L)**2) &
                          + exp(-0.5_rk*((d+n)/L)**2) )   ! exatamente definida positiva
       end do
       C(j,j) = C(j,j) + nugget*sig**2
    end do
  end subroutine build_cov

  function gaspari_cohn(d, c) result(r)
    real(rk), intent(in) :: d, c
    real(rk) :: r, z
    z = d/c
    if (z <= 1.0_rk) then
       r = -0.25_rk*z**5 + 0.5_rk*z**4 + 0.625_rk*z**3 - (5.0_rk/3)*z**2 + 1.0_rk
    else if (z <= 2.0_rk) then
       r = z**5/12 - 0.5_rk*z**4 + 0.625_rk*z**3 + (5.0_rk/3)*z**2 - 5*z + 4 - 2/(3*z)
    else
       r = 0.0_rk
    end if
  end function gaspari_cohn

  !--------------------------------------------------------------------
  ! Algebra linear: Cholesky (A = L L^T) e solucao de sistemas SPD
  !--------------------------------------------------------------------
  subroutine chol_factor(A, L)
    real(rk), intent(in)  :: A(:,:)
    real(rk), intent(out) :: L(:,:)
    integer :: i, j, n
    real(rk) :: s
    n = size(A,1); L = 0.0_rk
    do j = 1, n
       s = A(j,j) - dot_product(L(j,1:j-1), L(j,1:j-1))
       if (s <= 0.0_rk) then
          write(*,*) 'chol_factor: matriz nao e definida positiva, j=', j, ' s=', s
          stop 1
       end if
       L(j,j) = sqrt(s)
       do i = j+1, n
          L(i,j) = (A(i,j) - dot_product(L(i,1:j-1), L(j,1:j-1)))/L(j,j)
       end do
    end do
  end subroutine chol_factor

  function chol_solve(L, b) result(x)       ! resolve (L L^T) x = b, b(n,m)
    real(rk), intent(in) :: L(:,:), b(:,:)
    real(rk) :: x(size(b,1), size(b,2))
    integer :: i, n, j
    n = size(L,1)
    x = b
    do j = 1, size(b,2)
       do i = 1, n
          x(i,j) = (x(i,j) - dot_product(L(i,1:i-1), x(1:i-1,j)))/L(i,i)
       end do
       do i = n, 1, -1
          x(i,j) = (x(i,j) - dot_product(L(i+1:n,i), x(i+1:n,j)))/L(i,i)
       end do
    end do
  end function chol_solve

  function identity(n) result(I)
    integer, intent(in) :: n
    real(rk) :: I(n,n)
    integer :: k
    I = 0.0_rk
    do k = 1, n; I(k,k) = 1.0_rk; end do
  end function identity

  ! H como matriz (nobs x nx), so para fins didaticos
  function make_H() result(H)
    real(rk) :: H(nobs, nx)
    integer :: k
    H = 0.0_rk
    do k = 1, nobs; H(k, iobs(k)) = 1.0_rk; end do
  end function make_H

  !--------------------------------------------------------------------
  ! Gradiente conjugado para A x = b (A SPD, dado por produto matriz-vetor)
  !--------------------------------------------------------------------
  subroutine cg_solve(apply, b, x, tol, maxit, niter)
    procedure(matvec_if) :: apply
    real(rk), intent(in)  :: b(:)
    real(rk), intent(out) :: x(:)
    real(rk), intent(in)  :: tol
    integer,  intent(in)  :: maxit
    integer,  intent(out) :: niter
    real(rk) :: r(size(b)), p(size(b)), Ap(size(b)), rs, rsn, a, b2
    integer :: it
    x = 0.0_rk; r = b; p = r
    rs = dot_product(r,r); b2 = rs; niter = 0
    if (b2 == 0.0_rk) return
    do it = 1, maxit
       if (sqrt(rs) <= tol*sqrt(b2)) exit
       Ap = apply(p)
       a  = rs/dot_product(p, Ap)
       x  = x + a*p
       r  = r - a*Ap
       rsn = dot_product(r,r)
       p  = r + (rsn/rs)*p
       rs = rsn
       niter = it
    end do
  end subroutine cg_solve


  !--------------------------------------------------------------------
  ! DFI: filtro de Dolph-Chebyshev e inicializacao em dois estagios
  !   estagio 1: t=0 -> -TS, para tras, SEM difusao, acumulando h_k c(t_k)
  !   estagio 2: -TS/2 -> +TS/2, para frente, acumulando os mesmos pesos
  ! Propagador: leapfrog centrado (reversivel no tempo, aceita dt<0),
  ! difusao defasada, 1o passo por Runge-Kutta de ponto medio.
  !--------------------------------------------------------------------
  pure function cheb(n, x) result(t)
    integer,  intent(in) :: n
    real(rk), intent(in) :: x
    real(rk) :: t
    if (abs(x) <= 1.0_rk) then
       t = cos(real(n,rk)*acos(x))
    else
       t = cosh(real(n,rk)*acosh(x))
    end if
  end function cheb

  subroutine dolph(m, ths, h, x0, r)
    integer,  intent(in)  :: m
    real(rk), intent(in)  :: ths
    real(rk), intent(out) :: h(0:2*m), x0, r
    integer  :: nn, k, mi
    real(rk) :: thm, sm
    nn = 2*m + 1
    x0 = 1.0_rk/cos(ths/2.0_rk)
    r  = 1.0_rk/cosh(2.0_rk*real(m,rk)*acosh(x0))
    do k = -m, m
       sm = 0.0_rk
       do mi = 1, m
          thm = 2.0_rk*pi*real(mi,rk)/real(nn,rk)
          sm  = sm + cheb(2*m, x0*cos(thm/2.0_rk))*cos(real(k,rk)*thm)
       end do
       h(k+m) = (1.0_rk + 2.0_rk*r*sm)/real(nn,rk)
    end do
  end subroutine dolph

  pure function lf_tend(c, u, adv, dif) result(f)
    real(rk), intent(in) :: c(:), u
    logical,  intent(in) :: adv, dif
    real(rk) :: f(size(c))
    integer :: j, n, jp, jm
    n = size(c); f = 0.0_rk
    do j = 1, n
       jp = j+1; if (j == n) jp = 1
       jm = j-1; if (j == 1) jm = n
       if (adv) f(j) = f(j) - (u + alpha*c(j))*(c(jp)-c(jm))/(2.0_rk*dx)
       if (dif) f(j) = f(j) + kappa*(c(jp)-2.0_rk*c(j)+c(jm))/dx**2
    end do
  end function lf_tend

  ! integra ns passos de leapfrog (dtl pode ser < 0) acumulando h(s)*c(s)
  subroutine lf_accum(c0, dtl, ns, dif, u, h, acc)
    real(rk), intent(in)  :: c0(:), dtl, u, h(0:)
    integer,  intent(in)  :: ns
    logical,  intent(in)  :: dif
    real(rk), intent(out) :: acc(:)
    real(rk) :: cold(size(c0)), cnow(size(c0)), cnew(size(c0)), cs(size(c0))
    integer :: s
    cold = c0; acc = h(0)*cold
    cs   = cold + 0.5_rk*dtl*lf_tend(cold, u, .true., dif)
    cnow = cold + dtl*lf_tend(cs, u, .true., dif)
    acc  = acc + h(1)*cnow
    do s = 2, ns
       cnew = cold + 2.0_rk*dtl*lf_tend(cnow, u, .true., .false.)
       if (dif) cnew = cnew + 2.0_rk*dtl*lf_tend(cold, u, .false., .true.)
       cold = cnow; cnow = cnew
       acc = acc + h(s)*cnow
    end do
  end subroutine lf_accum

  subroutine dfi_state0(c)           ! DFI no estado inicial (se use_dfi e dfi_init0)
    real(rk), intent(inout) :: c(:)
    if (use_dfi .and. dfi_init0) c = dfi_init(c, u_model)
  end subroutine dfi_state0

  function dfi_init(c0, u) result(ci)
    real(rk), intent(in) :: c0(:), u
    real(rk) :: ci(size(c0))
    real(rk), allocatable :: h(:)
    real(rk) :: cbar(size(c0)), x0, r
    integer :: ns
    ns = 2*dfi_M
    allocate(h(0:ns))
    call dolph(dfi_M, 2.0_rk*pi*dt/dfi_tau, h, x0, r)
    call lf_accum(c0,   -dt, ns, .false.,   u, h, cbar)   ! valido em -TS/2
    call lf_accum(cbar,  dt, ns, dfi_diab,  u, h, ci)     ! valido em t=0
  end function dfi_init

  !--------------------------------------------------------------------
  ! Numeros aleatorios
  !--------------------------------------------------------------------
  subroutine seed_rng(s)
    integer, intent(in) :: s
    integer, allocatable :: sd(:)
    integer :: n, i
    call random_seed(size=n)
    allocate(sd(n))
    do i = 1, n; sd(i) = s + 104729*i; end do
    call random_seed(put=sd)
  end subroutine seed_rng

  function randn() result(z)                 ! N(0,1) por Box-Muller
    real(rk) :: z, r1, r2
    call random_number(r1); call random_number(r2)
    if (r1 < 1.0e-300_rk) r1 = 1.0e-300_rk
    z = sqrt(-2.0_rk*log(r1))*cos(2.0_rk*pi*r2)
  end function randn

  function randn_vec(n) result(z)
    integer, intent(in) :: n
    real(rk) :: z(n)
    integer :: i
    do i = 1, n; z(i) = randn(); end do
  end function randn_vec

  pure function rmse(a, b) result(r)
    real(rk), intent(in) :: a(:), b(:)
    real(rk) :: r
    r = sqrt(sum((a-b)**2)/size(a))
  end function rmse

  !--------------------------------------------------------------------
  ! Saida: <prefixo>.bin/.ctl (GrADS) e <prefixo>_rmse.dat
  ! variaveis por tempo: livre, prev, verd, anal
  !--------------------------------------------------------------------
  subroutine open_outputs(prefix, extra_label)
    character(*), intent(in) :: prefix
    character(*), intent(in), optional :: extra_label
    real(sp) :: tmp(nx)
    integer :: lrec
    inquire(iolength=lrec) tmp
    open(ugr, file=trim(prefix)//'.bin', form='unformatted', access='direct', &
         recl=lrec, status='replace')
    open(urm, file=trim(prefix)//'_rmse.dat', status='replace')
    if (present(extra_label)) then
       write(urm,'(A)') '# passo  rmse_livre  rmse_prev  rmse_anal  '//trim(extra_label)
    else
       write(urm,'(A)') '# passo  rmse_livre  rmse_prev  rmse_anal'
    end if
    irec = 0; ntime = 0; nsum = 0; s_free = 0; s_b = 0; s_a = 0
  end subroutine open_outputs

  subroutine log_step(n, xt, xfree, xb, xa, extra)
    integer,  intent(in) :: n
    real(rk), intent(in) :: xt(:), xfree(:), xb(:), xa(:)
    real(rk), intent(in), optional :: extra
    real(rk) :: rl, rb, ra
    rl = rmse(xfree, xt); rb = rmse(xb, xt); ra = rmse(xa, xt)
    if (present(extra)) then
       write(urm,'(I6,4ES14.5)') n, rl, rb, ra, extra
    else
       write(urm,'(I6,3ES14.5)') n, rl, rb, ra
    end if
    irec = irec+1; write(ugr, rec=irec) real(xfree, sp)
    irec = irec+1; write(ugr, rec=irec) real(xb,    sp)
    irec = irec+1; write(ugr, rec=irec) real(xt,    sp)
    irec = irec+1; write(ugr, rec=irec) real(xa,    sp)
    ntime = ntime + 1
    if (n >= 1) then
       nsum = nsum + 1; s_free = s_free + rl; s_b = s_b + rb; s_a = s_a + ra
    end if
  end subroutine log_step

  subroutine close_outputs(prefix, titulo)
    character(*), intent(in) :: prefix, titulo
    integer :: uc
    close(ugr); close(urm)
    open(newunit=uc, file=trim(prefix)//'.ctl', status='replace')
    write(uc,'(A)')    'dset ^'//trim(prefix)//'.bin'
    write(uc,'(A)')    'title '//trim(titulo)
    write(uc,'(A)')    'undef -9999.9'
    write(uc,'(A,I0,A,F8.3)') 'xdef ', nx, ' linear 0.0 ', dx
    write(uc,'(A)')    'ydef 1 linear 0 1'
    write(uc,'(A)')    'zdef 1 levels 1000'
    write(uc,'(A,I0,A)') 'tdef ', ntime, ' linear 00z01jan2000 1hr'
    write(uc,'(A)')    'vars 4'
    write(uc,'(A)')    'livre 0 99 previsao sem assimilacao'
    write(uc,'(A)')    'prev  0 99 previsao (background) antes da analise'
    write(uc,'(A)')    'verd  0 99 verdade'
    write(uc,'(A)')    'anal  0 99 analise'
    write(uc,'(A)')    'endvars'
    close(uc)
    write(*,'(A)')        ' ---------------------------------------------------------'
    write(*,'(A,A)')      ' Resumo (RMSE medio, passos 1..nt): ', trim(titulo)
    write(*,'(A,F9.5)')   '   sem assimilacao : ', s_free/nsum
    write(*,'(A,F9.5)')   '   previsao (bkg)  : ', s_b/nsum
    write(*,'(A,F9.5)')   '   analise         : ', s_a/nsum
    write(*,'(A)')        ' Arquivos: '//trim(prefix)//'.bin/.ctl  '//trim(prefix)//'_rmse.dat'
    write(*,'(A)')        ' ---------------------------------------------------------'
  end subroutine close_outputs

end module da_mod
