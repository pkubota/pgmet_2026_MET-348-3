!======================================================================
! Programa : enkf_advec_diff  -  Filtro de Kalman por Conjunto (EnKF)
!   EnKF estocastico (observacoes perturbadas), nens membros.
!   P^f estimada pelo conjunto:  P^f = X' X'^T / (N-1)
!   K = (rho o P^f H^T) (rho_oo o H P^f H^T + R)^-1      (localizacao GC)
!   x_m^a = x_m^f + K (y + eps_m - H x_m^f),  eps_m ~ N(0,R)
! Inflacao multiplicativa antes da analise. Modelo NAO linear + ruido Q.
!======================================================================
program enkf_advec_diff
  use da_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:)
  real(rk), allocatable :: xfree(:), xb(:), xa(:)
  real(rk), allocatable :: E(:,:), X(:,:), HX(:,:), PHt(:,:), HPHt(:,:)
  real(rk), allocatable :: B(:,:), LB(:,:), Q(:,:), LQ(:,:), rho(:,:)
  real(rk), allocatable :: S(:,:), LS(:,:), Kt(:,:), Kg(:,:), yp(:)
  real(rk) :: dist
  integer :: n, m, i, j, k

  call read_config(); call setup_obs()
  call seed_rng(seed0 + 777)                 ! sequencia propria do EnKF
  allocate(xfree(nx), xb(nx), xa(nx), E(nx,nens), X(nx,nens), HX(nobs,nens), &
           PHt(nx,nobs), HPHt(nobs,nobs), B(nx,nx), LB(nx,nx), Q(nx,nx),     &
           LQ(nx,nx), rho(nx,nobs), S(nobs,nobs), LS(nobs,nobs),            &
           Kt(nobs,nx), Kg(nx,nobs), yp(nobs))
  call make_experiment(xt_all, y_all)
  call seed_rng(seed0 + 777)
  call build_cov(sig_b, lcorr, B); call chol_factor(B, LB)
  call build_cov(sig_q, lcorr, Q); call chol_factor(Q, LQ)

  ! localizacao Gaspari-Cohn entre ponto de grade i e observacao k
  do k = 1, nobs
     do i = 1, nx
        dist = abs(real(i - iobs(k), rk)); dist = min(dist, nx - dist)
        if (loc_rad > 0.0_rk) then
           rho(i,k) = gaspari_cohn(dist, loc_rad)
        else
           rho(i,k) = 1.0_rk
        end if
     end do
  end do

  call init_background(xb); xfree = xb; call dfi_state0(xb)
  do m = 1, nens                              ! conjunto inicial ~ N(xb, B)
     E(:,m) = xb + matmul(LB, randn_vec(nx))
  end do
  xa = sum(E, dim=2)/nens
  call open_outputs('enkf', 'espalhamento_anal')
  call log_step(0, xt_all(:,0), xfree, xb, xa, spread_of(E))

  do n = 1, nt
     xfree = model_step(xfree, u_model)
     do m = 1, nens                           ! previsao de cada membro (+ ruido de modelo)
        E(:,m) = model_step(E(:,m), u_model) + matmul(LQ, randn_vec(nx))
     end do
     xb = sum(E, dim=2)/nens
     if (mod(n, obs_every) == 0) then
        ! inflacao multiplicativa
        do m = 1, nens; E(:,m) = xb + infl*(E(:,m) - xb); end do
        do m = 1, nens; X(:,m) = (E(:,m) - xb)/sqrt(real(nens-1,rk)); end do
        do k = 1, nobs; HX(k,:) = X(iobs(k),:); end do
        PHt  = matmul(X, transpose(HX))
        HPHt = matmul(HX, transpose(HX))
        do k = 1, nobs
           PHt(:,k) = PHt(:,k)*rho(:,k)
           do j = 1, nobs; HPHt(k,j) = HPHt(k,j)*rho(iobs(k),j); end do
           HPHt(k,k) = HPHt(k,k) + sig_o**2
        end do
        S = HPHt
        call chol_factor(S, LS)
        Kt = chol_solve(LS, transpose(PHt))
        Kg = transpose(Kt)
        do m = 1, nens                         ! observacoes perturbadas
           do k = 1, nobs
              yp(k) = y_all(k,n) + sig_o*randn() - E(iobs(k),m)
           end do
           E(:,m) = E(:,m) + matmul(Kg, yp)
           if (use_dfi) E(:,m) = dfi_init(E(:,m), u_model)   ! DFI opcional em cada membro
        end do
        xa = sum(E, dim=2)/nens
     else
        xa = xb
     end if
     call log_step(n, xt_all(:,n), xfree, xb, xa, spread_of(E))
  end do
  call close_outputs('enkf', 'EnKF estocastico (N membros, localizacao GC)')
contains
  function spread_of(Ens) result(s)            ! espalhamento medio do conjunto
    real(rk), intent(in) :: Ens(:,:)
    real(rk) :: s, mu(size(Ens,1))
    integer :: mm
    mu = sum(Ens, dim=2)/size(Ens,2)
    s = 0.0_rk
    do mm = 1, size(Ens,2); s = s + sum((Ens(:,mm)-mu)**2); end do
    s = sqrt(s/((size(Ens,2)-1)*size(Ens,1)))
  end function spread_of
end program enkf_advec_diff
