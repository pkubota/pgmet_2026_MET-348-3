!======================================================================
! Programa : dfi_demo - valida a DFI do da_mod contra o teste original
!   (gaussiana sigma=20 km, U=10 m/s, ruido 8dx-3dx, M=10, tau=900 s).
!   Valores de referencia (seu README): RMSE t=0  NIL 0,0519  DFI 0,0045  diab 0,0046
!======================================================================
program dfi_demo
  use da_mod
  implicit none
  real(rk), allocatable :: x(:), ct(:), cn(:), cd(:), cdd(:)
  real(rk) :: xlen, s0, x0c
  integer :: i, m
  nx = 400; xlen = 400.0e3_rk; dx = xlen/nx; dt = 50.0_rk
  kappa = 100.0_rk; alpha = 0.0_rk; dfi_M = 10; dfi_tau = 900.0_rk
  s0 = 20.0e3_rk; x0c = 120.0e3_rk
  allocate(x(nx), ct(nx), cn(nx), cd(nx), cdd(nx))
  do i = 1, nx; x(i) = (i-0.5_rk)*dx; end do
  do i = 1, nx
     ct(i) = 0.0_rk
     do m = -1, 1
        ct(i) = ct(i) + exp(-0.5_rk*(x(i)-x0c-m*xlen)**2/s0**2)
     end do
  end do
  cn = ct
  do m = nx/8, nx/3
     cn = cn + 0.008_rk*cos(2*pi*m*x/xlen + 2*pi*modulo(m*0.6180339887498949_rk,1.0_rk))
  end do
  cd = dfi_init(cn, 10.0_rk)
  dfi_diab = .true.; cdd = dfi_init(cn, 10.0_rk)
  write(*,'(A,3F9.5)') ' RMSE t=0 (NIL, DFI, DFI-diab): ', rmse(cn,ct), rmse(cd,ct), rmse(cdd,ct)
  write(*,'(A)')       ' referencia (Python/Fortran originais): 0.05190  0.00450  0.00460'
end program dfi_demo
