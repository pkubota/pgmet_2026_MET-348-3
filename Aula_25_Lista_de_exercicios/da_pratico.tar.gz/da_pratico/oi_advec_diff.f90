!======================================================================
! Programa : oi_advec_diff  -  Interpolacao Otima (OI) ciclada
!   xa = xb + B H^T (H B H^T + R)^-1 (y - H xb)
! B estatica, gaussiana (nao diagonal). A analise REALIMENTA o modelo.
!======================================================================
program oi_advec_diff
  use da_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:)
  real(rk), allocatable :: xt(:), xfree(:), xb(:), xa(:)
  real(rk), allocatable :: B(:,:), S(:,:), LS(:,:), w(:,:), d(:)
  integer :: n, i, j, k
  real(rk) :: chi2, chi2_sum
  integer :: nan

  call read_config(); call setup_obs()
  allocate(xt(nx), xfree(nx), xb(nx), xa(nx), B(nx,nx), S(nobs,nobs), &
           LS(nobs,nobs), w(nobs,1), d(nobs))
  call make_experiment(xt_all, y_all)
  call build_cov(sig_b, lcorr, B)

  ! S = H B H^T + R : H seleciona linhas/colunas -> B(iobs,iobs)
  do j = 1, nobs
     do i = 1, nobs
        S(i,j) = B(iobs(i), iobs(j))
     end do
     S(j,j) = S(j,j) + sig_o**2
  end do
  call chol_factor(S, LS)                ! B e R constantes: fatora UMA vez

  call init_background(xb); xfree = xb; call dfi_state0(xb); xa = xb
  call open_outputs('oi')
  call log_step(0, xt_all(:,0), xfree, xb, xa)
  chi2_sum = 0; nan = 0

  do n = 1, nt
     xfree = model_step(xfree, u_model)       ! controle sem assimilacao
     xb    = model_step(xa,    u_model)       ! previsao a partir da analise
     if (mod(n, obs_every) == 0) then
        do k = 1, nobs
           d(k) = y_all(k,n) - xb(iobs(k))     ! inovacao
        end do
        w(:,1) = d
        w = chol_solve(LS, w)                  ! w = S^-1 d
        xa = xb
        do k = 1, nobs
           xa = xa + B(:, iobs(k))*w(k,1)      ! xa = xb + B H^T w
        end do
        if (use_dfi) xa = dfi_init(xa, u_model)      ! DFI opcional na analise
        chi2 = dot_product(d, w(:,1))/nobs     ! diagnostico: ~1 se B,R coerentes
        chi2_sum = chi2_sum + chi2; nan = nan + 1
     else
        xa = xb
     end if
     call log_step(n, xt_all(:,n), xfree, xb, xa)
  end do

  write(*,'(A,F8.3,A)') ' Diagnostico d^T S^-1 d / nobs (medio) = ', chi2_sum/nan, &
       '   (esperado ~1 se B e R estao bem especificados)'
  call close_outputs('oi', 'OI com B gaussiana (ciclada)')
end program oi_advec_diff
