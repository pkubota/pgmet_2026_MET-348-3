!======================================================================
! Programa : ekf_advec_diff  -  Filtro de Kalman Estendido (EKF)
! Modelo NAO linear (alpha > 0):  dc/dt + (U + alpha c) dc/dx = kappa c_xx
!   Previsao : xf = M(xa) (nao linear) ;  Pf = F Pa F^T + Q,  F = dM/dx |_xa
!   Analise  : identica ao KF (H linear)
! Verifica a Jacobiana contra diferencas finitas antes de rodar.
!======================================================================
program ekf_advec_diff
  use da_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:)
  real(rk), allocatable :: xfree(:), xb(:), xa(:), d(:), xtest(:), dxp(:)
  real(rk), allocatable :: F(:,:), P(:,:), Pf(:,:), Q(:,:), H(:,:), Kg(:,:)
  real(rk), allocatable :: S(:,:), LS(:,:), IKH(:,:), R(:,:), Kt(:,:)
  real(rk) :: eps, errjac
  integer :: n, k

  call read_config(); call setup_obs()
  if (alpha == 0.0_rk) write(*,'(A)') ' [EKF] aviso: alpha = 0 -> EKF coincide com o KF'
  allocate(xfree(nx), xb(nx), xa(nx), d(nobs), xtest(nx), dxp(nx), F(nx,nx), &
           P(nx,nx), Pf(nx,nx), Q(nx,nx), H(nobs,nx), Kg(nx,nobs),          &
           S(nobs,nobs), LS(nobs,nobs), IKH(nx,nx), R(nobs,nobs), Kt(nobs,nx))
  call make_experiment(xt_all, y_all)
  call build_cov(sig_b, lcorr, P)
  call build_cov(sig_q, lcorr, Q)
  H = make_H()
  R = 0.0_rk; do k = 1, nobs; R(k,k) = sig_o**2; end do

  ! --- teste da Jacobiana: [M(x+e p) - M(x - e p)]/(2e) = F p  (O(e^2)) ---
  call init_truth(xtest); dxp = randn_vec(nx)
  eps = 1.0e-6_rk
  F = model_jac(xtest, u_model)
  errjac = maxval(abs((model_step(xtest+eps*dxp,u_model) - model_step(xtest-eps*dxp,u_model))/(2*eps) &
                      - matmul(F, dxp)))
  write(*,'(A,ES10.3)') ' [EKF] teste da Jacobiana: max|dif. finitas - F p| = ', errjac

  call init_background(xb); xfree = xb; call dfi_state0(xb); xa = xb
  call open_outputs('ekf', 'tracoP_anal')
  call log_step(0, xt_all(:,0), xfree, xb, xa, trace(P))

  do n = 1, nt
     xfree = model_step(xfree, u_model)
     F  = model_jac(xa, u_model)                    ! linearizacao em torno da analise
     xb = model_step(xa, u_model)                   ! previsao NAO linear
     Pf = matmul(F, matmul(P, transpose(F))) + Q
     if (mod(n, obs_every) == 0) then
        S = matmul(H, matmul(Pf, transpose(H))) + R
        call chol_factor(S, LS)
        Kt = chol_solve(LS, matmul(H, Pf))
        Kg  = transpose(Kt)
        do k = 1, nobs; d(k) = y_all(k,n) - xb(iobs(k)); end do
        xa  = xb + matmul(Kg, d)
        if (use_dfi) xa = dfi_init(xa, u_model)      ! DFI opcional (so o estado; P inalterada)
        IKH = identity(nx) - matmul(Kg, H)
        P   = matmul(IKH, matmul(Pf, transpose(IKH))) + matmul(Kg, matmul(R, transpose(Kg)))
     else
        xa = xb; P = Pf
     end if
     call log_step(n, xt_all(:,n), xfree, xb, xa, trace(P))
  end do
  call close_outputs('ekf', 'Filtro de Kalman Estendido')
contains
  function trace(A) result(t)
    real(rk), intent(in) :: A(:,:)
    real(rk) :: t
    integer :: i
    t = 0.0_rk
    do i = 1, size(A,1); t = t + A(i,i); end do
  end function trace
end program ekf_advec_diff
