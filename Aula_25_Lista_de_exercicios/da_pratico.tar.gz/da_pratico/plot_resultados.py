#!/usr/bin/env python3
"""Figura comparativa: RMSE no tempo e perfis no passo final. Uso: make plot"""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SUP, INK, MUTED = "#fcfcfb", "#0b0b0b", "#52514e"
metodos = [("oi", "OI / 3D-Var (idênticos)", "#2a78d6", "-"),
           ("ekf", "EKF", "#eb6834", "-"),
           ("enkf", "EnKF (20 membros)", "#1baf7a", "-"),
           ("var4d", "4D-Var", "#e87ba4", "-"),
           ("kf", "KF (modelo linear, α=0)", "#eda100", "--")]
NX = 50

def rmse(p): return np.loadtxt(f"{p}_rmse.dat")
def perfis(p, nt):
    a = np.fromfile(f"{p}.bin", dtype="<f4").reshape(-1, 4, NX)  # tempo, var, x
    return a[nt]

fig, ax = plt.subplots(1, 2, figsize=(12, 4.4), facecolor=SUP)
d = rmse("oi")
ax[0].plot(d[:, 0], d[:, 1], color="#8a8985", lw=2, label="sem assimilação")
for p, nome, c, ls in metodos:
    d = rmse(p)
    ax[0].plot(d[:, 0], d[:, 3], color=c, lw=2, ls=ls, label=nome)
ax[0].set(xlabel="passo de tempo", ylabel="RMSE da análise", title="Erro da análise ao longo do ciclo")
ax[0].legend(frameon=False, fontsize=8)

o = perfis("oi", 100); k = perfis("var4d", 100); e = perfis("enkf", 100)
x = np.arange(NX)
ax[1].plot(x, o[2], color=INK, lw=2.4, label="verdade")
ax[1].plot(x, o[0], color="#8a8985", lw=2, label="sem assimilação")
ax[1].plot(x, o[3], color="#2a78d6", lw=2, label="OI")
ax[1].plot(x, e[3], color="#1baf7a", lw=2, label="EnKF")
ax[1].plot(x, k[3], color="#e87ba4", lw=2, label="4D-Var")
ax[1].set(xlabel="ponto de grade", ylabel="c", title="Perfis no passo 100")
ax[1].legend(frameon=False, fontsize=8)
for a in ax:
    a.set_facecolor(SUP); a.grid(alpha=.25, lw=.6)
    for s in ("top", "right"): a.spines[s].set_visible(False)
    a.title.set_color(INK); a.xaxis.label.set_color(MUTED); a.yaxis.label.set_color(MUTED)
plt.tight_layout(); plt.savefig("comparacao.png", dpi=140, facecolor=SUP)
print("comparacao.png gerada")
