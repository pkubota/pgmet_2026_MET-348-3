#!/usr/bin/env python3
"""Cenario DFI: erro nos primeiros passos e perfis (OI) com/sem DFI."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
SUP, INK, MUTED = "#fcfcfb", "#0b0b0b", "#52514e"
cor = {"oi": "#2a78d6", "kf": "#eda100", "enkf": "#1baf7a", "var4d": "#e87ba4"}
nome = {"oi": "OI", "kf": "KF", "enkf": "EnKF", "var4d": "4D-Var"}
NX = 200
fig, ax = plt.subplots(1, 2, figsize=(12, 4.4), facecolor=SUP)
for p in cor:
    a = np.loadtxt(f"cen_sem_dfi/{p}_rmse.dat"); b = np.loadtxt(f"cen_com_dfi/{p}_rmse.dat")
    m = a[:, 0] <= 40
    ax[0].plot(a[m, 0], a[m, 3], color=cor[p], lw=1.6, ls="--", alpha=.8)
    ax[0].plot(b[m, 0], b[m, 3], color=cor[p], lw=2.2, label=nome[p])
    print(f"{nome[p]:7s} t=5: {a[5,3]:.4f} -> {b[5,3]:.4f}   t=10: {a[10,3]:.4f} -> {b[10,3]:.4f}   "
          f"media(1-20): {a[1:21,3].mean():.4f} -> {b[1:21,3].mean():.4f}")
ax[0].plot([], [], color=MUTED, ls="--", label="sem DFI (tracejado)")
ax[0].plot([], [], color=MUTED, lw=2.2, label="com DFI (cheio)")
ax[0].set(xlabel="passo de tempo", ylabel="RMSE da análise", title="Erro da análise nos primeiros passos")
ax[0].legend(frameon=False, fontsize=8)
rd = lambda d, t: np.fromfile(f"{d}/oi.bin", dtype="<f4").reshape(-1, 4, NX)[t]
s, c = rd("cen_sem_dfi", 5), rd("cen_com_dfi", 5)
x = np.arange(NX)
ax[1].plot(x, s[2], color=INK, lw=2.4, label="verdade")
ax[1].plot(x, s[3], color="#8a8985", lw=1.2, label="análise OI sem DFI")
ax[1].plot(x, c[3], color="#2a78d6", lw=2, label="análise OI com DFI")
ax[1].set(xlim=(0, 100), xlabel="ponto de grade", ylabel="c", title="Perfil na 1ª análise (passo 5)")
ax[1].legend(frameon=False, fontsize=8)
for a_ in ax:
    a_.set_facecolor(SUP); a_.grid(alpha=.25, lw=.6)
    for sp in ("top", "right"): a_.spines[sp].set_visible(False)
    a_.title.set_color(INK); a_.xaxis.label.set_color(MUTED); a_.yaxis.label.set_color(MUTED)
plt.tight_layout(); plt.savefig("cenario_dfi.png", dpi=140, facecolor=SUP)
