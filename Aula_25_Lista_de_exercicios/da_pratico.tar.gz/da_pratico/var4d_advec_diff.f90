!======================================================================
! Programa : var4d_advec_diff  -  4D-Var incremental (strong constraint)
!   J(v) = 1/2 v^T v + 1/2 sum_k (y_k - H M_{0,k}(x0))^T R^-1 (y_k - H M_{0,k}(x0))
!   x0 = xb + L v  (B = L L^T),  modelo perfeito dentro da janela.
! - Modelo tangente linear : dx_k = M_k dx_{k-1}   (Jacobiana do modelo)
! - Modelo ADJUNTO         : lam_{k-1} = M_k^T (lam_k + H^T R^-1 (...)_k)
!   (adjunto exato do modelo discretizado = transposta das Jacobianas)
! - Laco externo (nao linear) + laco interno (CG sobre a quadratica)
! - Teste do gradiente (adjunto x diferencas finitas) na 1a janela
!======================================================================
module var4d_mod
  use da_mod
  implicit none
  real(rk), allocatable :: Jk(:,:,:)      ! Jk(:,:,k) = dM/dx em traj(:,k-1)
  real(rk), allocatable :: LBm(:,:)       ! fator de Cholesky de B
  real(rk), allocatable :: ywin(:,:)      ! observacoes da janela (nobs, nwin)
contains
  ! integra o modelo nao linear na janela; opcionalmente guarda as Jacobianas
  subroutine traj_forward(x0, traj, linearize)
    real(rk), intent(in)  :: x0(:)
    real(rk), intent(out) :: traj(:,0:)
    logical,  intent(in)  :: linearize
    integer :: k
    traj(:,0) = x0
    do k = 1, nwin
       if (linearize) Jk(:,:,k) = model_jac(traj(:,k-1), u_model)
       traj(:,k) = model_step(traj(:,k-1), u_model)
    end do
  end subroutine traj_forward

  ! lam0 = sum_k M_{0,k}^T g_k   (varredura ADJUNTA, para tras no tempo)
  function adj_sum(g) result(lam)
    real(rk), intent(in) :: g(:,:)
    real(rk) :: lam(size(g,1))
    integer :: k
    lam = 0.0_rk
    do k = nwin, 1, -1
       lam = lam + g(:,k)
       lam = matmul(transpose(Jk(:,:,k)), lam)
    end do
  end function adj_sum

  ! (I + L^T [sum M^T H^T R^-1 H M] L) v : TL para frente + adjunto para tras
  function hess4d(v) result(av)
    real(rk), intent(in) :: v(:)
    real(rk) :: av(size(v))
    real(rk) :: dxs(size(v)), g(size(v), nwin)
    integer :: k, ko
    dxs = matmul(LBm, v); g = 0.0_rk
    do k = 1, nwin
       dxs = matmul(Jk(:,:,k), dxs)
       if (mod(k, obs_every) == 0) then
          do ko = 1, nobs; g(iobs(ko), k) = dxs(iobs(ko))/sig_o**2; end do
       end if
    end do
    av = v + matmul(transpose(LBm), adj_sum(g))
  end function hess4d

  ! custo nao linear J(v) e (opcional) gradiente via adjunto
  subroutine cost_grad(v, xbw, J, grad)
    real(rk), intent(in)  :: v(:), xbw(:)
    real(rk), intent(out) :: J
    real(rk), intent(out), optional :: grad(:)
    real(rk) :: traj(size(v), 0:nwin), g(size(v), nwin), dd
    integer :: k, ko
    call traj_forward(xbw + matmul(LBm, v), traj, present(grad))
    J = 0.5_rk*dot_product(v, v); g = 0.0_rk
    do k = obs_every, nwin, obs_every
       do ko = 1, nobs
          dd = ywin(ko,k) - traj(iobs(ko),k)
          J = J + 0.5_rk*dd**2/sig_o**2
          g(iobs(ko),k) = dd/sig_o**2
       end do
    end do
    if (present(grad)) grad = v - matmul(transpose(LBm), adj_sum(g))
  end subroutine cost_grad
end module var4d_mod

program var4d_advec_diff
  use da_mod
  use var4d_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:), xfree(:,:)
  real(rk), allocatable :: B(:,:), xbw(:), x0(:), v(:), dv(:), rhs(:), g(:,:)
  real(rk), allocatable :: trajb(:,:), traj(:,:), p(:), grad(:)
  real(rk) :: Jv, Jp, J0, eps, gp
  integer :: n, k, ic, nc, n0, io, ko, nit, ntest
  real(rk), allocatable :: xbi(:)

  call read_config(); call setup_obs()
  allocate(B(nx,nx), LBm(nx,nx), xbw(nx), x0(nx), v(nx), dv(nx), rhs(nx), &
           g(nx,nwin), trajb(nx,0:nwin), traj(nx,0:nwin), p(nx), grad(nx), &
           Jk(nx,nx,nwin), ywin(nobs,nwin), xfree(nx,0:nt), xbi(nx))
  call make_experiment(xt_all, y_all)
  call build_cov(sig_b, lcorr, B); call chol_factor(B, LBm)
  nc = nt/nwin
  if (nc*nwin /= nt) stop 'erro: nt deve ser multiplo de nwin'

  call init_background(xbi); xfree(:,0) = xbi; call dfi_state0(xbi)
  do n = 1, nt; xfree(:,n) = model_step(xfree(:,n-1), u_model); end do

  call open_outputs('var4d')
  call log_step(0, xt_all(:,0), xfree(:,0), xbi, xbi)
  xbw = xbi

  do ic = 1, nc
     n0 = (ic-1)*nwin
     do k = 1, nwin
        ywin(:,k) = y_all(:, n0+k)
     end do
     call traj_forward(xbw, trajb, .false.)       ! previsao de background na janela
     v = 0.0_rk; x0 = xbw

     if (ic == 1) then                            ! --- teste do gradiente ---
        call cost_grad(v, xbw, J0, grad)
        p = randn_vec(nx); p = p/sqrt(dot_product(p,p)); gp = dot_product(grad, p)
        write(*,'(A)') ' Teste do gradiente (1a janela): [J(v+e p)-J(v)]/(e g.p) -> 1'
        eps = 1.0e-2_rk
        do ntest = 1, 5
           call cost_grad(v + eps*p, xbw, Jp)
           write(*,'(A,ES8.1,A,F12.8)') '   e =', eps, '   razao = ', (Jp - J0)/(eps*gp)
           eps = eps*0.1_rk
        end do
     end if

     do io = 1, nouter                            ! --- laco externo (Gauss-Newton) ---
        call traj_forward(x0, traj, .true.)
        g = 0.0_rk
        do k = obs_every, nwin, obs_every
           do ko = 1, nobs
              g(iobs(ko),k) = (ywin(ko,k) - traj(iobs(ko),k))/sig_o**2
           end do
        end do
        rhs = matmul(transpose(LBm), adj_sum(g)) - v     ! -grad
        call cg_solve(hess4d, rhs, dv, 1.0e-8_rk, 100, nit)
        if (ic == 1) then
           call cost_grad(v, xbw, Jv)
           write(*,'(A,I0,A,ES11.4,A,I0,A)') ' janela 1, externo ', io, ': J antes = ', Jv, &
                '  (CG: ', nit, ' iter.)'
        end if
        v = v + dv; x0 = xbw + matmul(LBm, v)
        if (ic == 1) then
           call cost_grad(v, xbw, Jv)
           write(*,'(A,ES11.4)') '                        J depois = ', Jv
        end if
     end do
     call traj_forward(x0, traj, .false.)         ! trajetoria da analise
     do k = 1, nwin
        call log_step(n0+k, xt_all(:,n0+k), xfree(:,n0+k), trajb(:,k), traj(:,k))
     end do
     xbw = traj(:,nwin)                           ! background da proxima janela
     if (use_dfi) xbw = dfi_init(xbw, u_model)    ! DFI opcional no estado que inicia o proximo ciclo
  end do
  call close_outputs('var4d', '4D-Var incremental (strong constraint)')
end program var4d_advec_diff
