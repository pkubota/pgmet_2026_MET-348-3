!======================================================================
! Programa : kf_advec_diff  -  Filtro de Kalman (KF) linear
!   Previsao : xf = M xa ;           Pf = M Pa M^T + Q
!   Analise  : Kg = Pf H^T (H Pf H^T + R)^-1
!              xa = xf + Kg (y - H xf) ;  Pa = (I-KH) Pf (I-KH)^T + Kg R Kg^T (Joseph)
! Modelo LINEAR (alpha = 0): M e uma matriz constante. A covariancia P
! EVOLUI com o modelo (diferenca fundamental em relacao a OI/3D-Var).
!======================================================================
program kf_advec_diff
  use da_mod
  implicit none
  real(rk), allocatable :: xt_all(:,:), y_all(:,:)
  real(rk), allocatable :: xfree(:), xb(:), xa(:), d(:)
  real(rk), allocatable :: M(:,:), P(:,:), Pf(:,:), Q(:,:), H(:,:), Kg(:,:)
  real(rk), allocatable :: S(:,:), LS(:,:), IKH(:,:), R(:,:), Kt(:,:)
  integer :: n, k

  call read_config(); call setup_obs()
  alpha = 0.0_rk                          ! KF exige modelo linear (truth e modelo)
  write(*,'(A)') ' [KF] alpha forcado a 0 (modelo linear)'
  allocate(xfree(nx), xb(nx), xa(nx), d(nobs), M(nx,nx), P(nx,nx), Pf(nx,nx), &
           Q(nx,nx), H(nobs,nx), Kg(nx,nobs), S(nobs,nobs), LS(nobs,nobs),    &
           IKH(nx,nx), R(nobs,nobs), Kt(nobs,nx))
  call make_experiment(xt_all, y_all)
  call build_cov(sig_b, lcorr, P)          ! P0 = B
  call build_cov(sig_q, lcorr, Q)          ! erro de modelo
  H = make_H()
  R = 0.0_rk; do k = 1, nobs; R(k,k) = sig_o**2; end do
  M = model_jac(xb_dummy(), u_model)       ! alpha = 0: independe do estado

  call init_background(xb); xfree = xb; call dfi_state0(xb); xa = xb
  call open_outputs('kf', 'tracoP_anal')
  call log_step(0, xt_all(:,0), xfree, xb, xa, trace(P))

  do n = 1, nt
     xfree = model_step(xfree, u_model)
     xb    = matmul(M, xa)                       ! previsao do estado
     Pf    = matmul(M, matmul(P, transpose(M))) + Q   ! previsao da covariancia
     if (mod(n, obs_every) == 0) then
        S = matmul(H, matmul(Pf, transpose(H))) + R
        call chol_factor(S, LS)
        Kt = chol_solve(LS, matmul(H, Pf))       ! Kg^T = S^-1 H Pf  (S, Pf simetricas)
        Kg  = transpose(Kt)
        do k = 1, nobs; d(k) = y_all(k,n) - xb(iobs(k)); end do
        xa  = xb + matmul(Kg, d)
        if (use_dfi) xa = dfi_init(xa, u_model)      ! DFI opcional (so o estado; P inalterada)
        IKH = identity(nx) - matmul(Kg, H)
        P   = matmul(IKH, matmul(Pf, transpose(IKH))) + matmul(Kg, matmul(R, transpose(Kg)))
     else
        xa = xb; P = Pf
     end if
     call log_step(n, xt_all(:,n), xfree, xb, xa, trace(P))
  end do
  call close_outputs('kf', 'Filtro de Kalman linear')
contains
  function xb_dummy() result(z)
    real(rk) :: z(nx)
    z = 0.0_rk
  end function xb_dummy
  function trace(A) result(t)
    real(rk), intent(in) :: A(:,:)
    real(rk) :: t
    integer :: i
    t = 0.0_rk
    do i = 1, size(A,1); t = t + A(i,i); end do
  end function trace
end program kf_advec_diff
